import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { amount, currency = "INR", description, listing_type, listing_name, user_id } = await req.json();

    if (!amount || amount < 100) {
      return new Response(
        JSON.stringify({ error: "Amount must be at least 100 paise (1 INR)" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const razorpayKeyId = Deno.env.get("RAZORPAY_KEY_ID");
    const razorpayKeySecret = Deno.env.get("RAZORPAY_KEY_SECRET");

    // If Razorpay keys are not configured, return a simulated order
    // The frontend will handle the simulated flow
    if (!razorpayKeyId || !razorpayKeySecret) {
      return new Response(
        JSON.stringify({
          simulated: true,
          order_id: `order_sim_${Date.now()}`,
          amount,
          currency,
          message: "Razorpay not configured. Simulated order created.",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create a real Razorpay order
    const auth = btoa(`${razorpayKeyId}:${razorpayKeySecret}`);

    const orderResponse = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Basic ${auth}`,
      },
      body: JSON.stringify({
        amount,
        currency,
        receipt: `krishi_${Date.now()}`,
        notes: {
          description: description ?? "KrishiShare booking",
          listing_type: listing_type ?? "",
          listing_name: listing_name ?? "",
          user_id: user_id ?? "",
        },
      }),
    });

    if (!orderResponse.ok) {
      const errBody = await orderResponse.json().catch(() => ({}));
      const code = errBody?.error?.code ?? "";
      const description = errBody?.error?.description ?? "Unknown error";

      // If auth failed, the keys are invalid — fall back to simulated mode
      if (orderResponse.status === 401 || code === "BAD_REQUEST_ERROR" && description === "Authentication failed") {
        return new Response(
          JSON.stringify({
            simulated: true,
            order_id: `order_sim_${Date.now()}`,
            amount,
            currency,
            message: "Razorpay authentication failed. Running in simulated mode.",
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ error: `Razorpay order creation failed: ${description}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const order = await orderResponse.json();

    return new Response(
      JSON.stringify({
        key_id: razorpayKeyId,
        order_id: order.id,
        amount: order.amount,
        currency: order.currency,
        simulated: false,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
