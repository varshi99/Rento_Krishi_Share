import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { userId } = await req.json();
    if (!userId) {
      return new Response(JSON.stringify({ error: "userId is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceKey);

    // Fetch user profile
    const { data: profile } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .maybeSingle();

    // Fetch user's booking history
    const { data: bookings } = await supabase
      .from("bookings")
      .select("*")
      .eq("booker_id", userId)
      .order("created_at", { ascending: false })
      .limit(20);

    // Fetch nearby equipment
    const { data: equipment } = await supabase
      .from("equipment")
      .select("*")
      .eq("available", true)
      .limit(10);

    // Fetch available workers
    const { data: workers } = await supabase
      .from("workers")
      .select("*")
      .eq("available", true)
      .limit(10);

    // Generate recommendations based on data analysis
    const recommendations: any[] = [];

    // Analyze booking patterns
    const bookingTypes = (bookings ?? []).reduce((acc: Record<string, number>, b: any) => {
      acc[b.listing_type] = (acc[b.listing_type] ?? 0) + 1;
      return acc;
    }, {});

    const mostBookedType = Object.entries(bookingTypes).sort((a, b) => b[1] - a[1])[0];

    // Equipment recommendation
    if (equipment && equipment.length > 0) {
      const topEquipment = equipment[0];
      recommendations.push({
        type: "equipment",
        title: `${topEquipment.name} recommended for you`,
        description: `Available near ${topEquipment.location ?? "your area"} at ₹${topEquipment.daily_rate}/day. This equipment matches your farming needs based on your profile.`,
        confidence_score: 0.82,
        metadata: { equipment_id: topEquipment.id, category: topEquipment.category },
      });
    }

    // Crop recommendation based on season (July = Kharif)
    const month = new Date().getMonth();
    const isKharif = month >= 5 && month <= 9;
    const seasonCrops = isKharif
      ? ["Rice", "Cotton", "Maize"]
      : ["Wheat", "Mustard", "Gram"];

    recommendations.push({
      type: "crop",
      title: `${seasonCrops[0]} is ideal for this season`,
      description: `Based on current ${isKharif ? "Kharif" : "Rabi"} season and weather patterns in your area, ${seasonCrops[0]} cultivation would be optimal. Expected yield: ${isKharif ? "4-6" : "3-5"} tons/hectare.`,
      confidence_score: 0.78,
      metadata: { crop: seasonCrops[0], season: isKharif ? "Kharif" : "Rabi" },
    });

    // Weather alert recommendation
    recommendations.push({
      type: "weather_alert",
      title: isKharif ? "Monsoon advisory: Ensure proper drainage" : "Cool weather ahead — plan irrigation",
      description: isKharif
        ? "Heavy rainfall expected this week. Check drainage systems and avoid low-lying field areas for sensitive crops."
        : "Temperature dropping over the next week. Schedule irrigation at midday and consider mulching to retain soil warmth.",
      confidence_score: 0.74,
      metadata: { alert_type: isKharif ? "rain" : "temperature", season: isKharif ? "Kharif" : "Rabi" },
    });

    // Worker recommendation
    if (workers && workers.length > 0) {
      const topWorker = workers[0];
      recommendations.push({
        type: "worker",
        title: `Skilled ${topWorker.skills.split(",")[0].trim()} worker available`,
        description: `${topWorker.skills} with ${topWorker.experience_years} years experience. Daily wage: ₹${topWorker.daily_wage}. Located near ${topWorker.location ?? "your area"}.`,
        confidence_score: 0.70,
        metadata: { worker_id: topWorker.id, skills: topWorker.skills },
      });
    }

    // Transport optimization recommendation
    recommendations.push({
      type: "transport",
      title: "Optimize transport with shared delivery",
      description: "Based on your booking patterns, combining transport bookings with nearby farmers could save up to 40% on logistics costs.",
      confidence_score: 0.65,
      metadata: { optimization: "shared_transport", potential_savings: "40%" },
    });

    return new Response(
      JSON.stringify({ recommendations }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
