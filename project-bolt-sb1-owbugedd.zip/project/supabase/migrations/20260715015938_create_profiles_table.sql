/*
# Create profiles table with role-based access

1. New Tables
- `profiles`
- `id` (uuid, primary key, references auth.users)
- `full_name` (text, not null)
- `phone` (text)
- `role` (text, not null, one of: farmer, equipment_owner, worker, transport_provider, admin)
- `location` (text)
- `avatar_url` (text)
- `created_at` (timestamp, defaults to now)
- `updated_at` (timestamp, defaults to now)

2. Security
- Enable RLS on `profiles`.
- Owner-scoped CRUD: each authenticated user can read/update their own profile.
- All authenticated users can read profiles (needed for marketplace listings).
- Only owner can insert (on signup) and update their profile.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text,
  role text NOT NULL CHECK (role IN ('farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin')),
  location text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read profiles (needed for marketplace)
DROP POLICY IF EXISTS "select_profiles" ON profiles;
CREATE POLICY "select_profiles" ON profiles FOR SELECT
  TO authenticated USING (true);

-- Users can insert their own profile (created on signup)
DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

-- Users can update their own profile
DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Users can delete their own profile
DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);