/*
# Create notifications, shared_bookings, transport_tracking, and ai_recommendations tables

1. New Tables
- `notifications` — in-app notifications for booking updates, payments, alerts
- `shared_bookings` — group bookings with cost sharing between farmers
- `shared_booking_participants` — participants in a shared booking
- `transport_tracking` — live tracking updates for transport deliveries
- `ai_recommendations` — AI-generated recommendations for equipment, workers, crops

2. Security
- Enable RLS on all tables.
- Owner-scoped CRUD: users manage their own notifications, shared bookings, tracking.
- Notifications: user can read/update/delete their own.
- Shared bookings: creator can manage; participants can read.
- Transport tracking: provider can add updates; booker can read.
- AI recommendations: user can read their own.
*/

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('booking', 'payment', 'weather', 'transport', 'system', 'review', 'shared_booking')),
  title text NOT NULL,
  message text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  link text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notifications" ON notifications;
CREATE POLICY "insert_own_notifications" ON notifications FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notifications" ON notifications;
CREATE POLICY "delete_own_notifications" ON notifications FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Shared bookings
CREATE TABLE IF NOT EXISTS shared_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  listing_type text NOT NULL CHECK (listing_type IN ('equipment', 'worker', 'transport')),
  listing_id uuid NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  total_cost numeric NOT NULL DEFAULT 0,
  per_person_cost numeric NOT NULL DEFAULT 0,
  max_participants integer NOT NULL DEFAULT 2,
  current_participants integer NOT NULL DEFAULT 1,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'full', 'closed', 'completed')),
  location text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE shared_bookings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_shared_bookings" ON shared_bookings;
CREATE POLICY "select_shared_bookings" ON shared_bookings FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_shared_bookings" ON shared_bookings;
CREATE POLICY "insert_own_shared_bookings" ON shared_bookings FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = creator_id);

DROP POLICY IF EXISTS "update_own_shared_bookings" ON shared_bookings;
CREATE POLICY "update_own_shared_bookings" ON shared_bookings FOR UPDATE
  TO authenticated USING (auth.uid() = creator_id) WITH CHECK (auth.uid() = creator_id);

DROP POLICY IF EXISTS "delete_own_shared_bookings" ON shared_bookings;
CREATE POLICY "delete_own_shared_bookings" ON shared_bookings FOR DELETE
  TO authenticated USING (auth.uid() = creator_id);

-- Shared booking participants
CREATE TABLE IF NOT EXISTS shared_booking_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shared_booking_id uuid NOT NULL REFERENCES shared_bookings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'joined' CHECK (status IN ('joined', 'left')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(shared_booking_id, user_id)
);

ALTER TABLE shared_booking_participants ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_shared_booking_participants" ON shared_booking_participants;
CREATE POLICY "select_shared_booking_participants" ON shared_booking_participants FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_shared_booking_participants" ON shared_booking_participants;
CREATE POLICY "insert_own_shared_booking_participants" ON shared_booking_participants FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_shared_booking_participants" ON shared_booking_participants;
CREATE POLICY "update_own_shared_booking_participants" ON shared_booking_participants FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_shared_booking_participants" ON shared_booking_participants;
CREATE POLICY "delete_own_shared_booking_participants" ON shared_booking_participants FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Transport tracking
CREATE TABLE IF NOT EXISTS transport_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  transport_id uuid NOT NULL,
  provider_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'picked_up', 'in_transit', 'delivered', 'cancelled')),
  current_location text,
  latitude numeric,
  longitude numeric,
  estimated_arrival timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE transport_tracking ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_transport_tracking" ON transport_tracking;
CREATE POLICY "select_transport_tracking" ON transport_tracking FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_transport_tracking" ON transport_tracking;
CREATE POLICY "insert_own_transport_tracking" ON transport_tracking FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = provider_id);

DROP POLICY IF EXISTS "update_own_transport_tracking" ON transport_tracking;
CREATE POLICY "update_own_transport_tracking" ON transport_tracking FOR UPDATE
  TO authenticated USING (auth.uid() = provider_id) WITH CHECK (auth.uid() = provider_id);

DROP POLICY IF EXISTS "delete_own_transport_tracking" ON transport_tracking;
CREATE POLICY "delete_own_transport_tracking" ON transport_tracking FOR DELETE
  TO authenticated USING (auth.uid() = provider_id);

-- AI recommendations
CREATE TABLE IF NOT EXISTS ai_recommendations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('equipment', 'worker', 'transport', 'crop', 'weather_alert')),
  title text NOT NULL,
  description text NOT NULL,
  confidence_score numeric DEFAULT 0.5 CHECK (confidence_score >= 0 AND confidence_score <= 1),
  metadata jsonb,
  is_dismissed boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_recommendations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_recommendations" ON ai_recommendations;
CREATE POLICY "select_own_recommendations" ON ai_recommendations FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_recommendations" ON ai_recommendations;
CREATE POLICY "insert_own_recommendations" ON ai_recommendations FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_recommendations" ON ai_recommendations;
CREATE POLICY "update_own_recommendations" ON ai_recommendations FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_recommendations" ON ai_recommendations;
CREATE POLICY "delete_own_recommendations" ON ai_recommendations FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_shared_bookings_creator_id ON shared_bookings(creator_id);
CREATE INDEX IF NOT EXISTS idx_shared_bookings_status ON shared_bookings(status);
CREATE INDEX IF NOT EXISTS idx_shared_booking_participants_booking_id ON shared_booking_participants(shared_booking_id);
CREATE INDEX IF NOT EXISTS idx_transport_tracking_booking_id ON transport_tracking(booking_id);
CREATE INDEX IF NOT EXISTS idx_ai_recommendations_user_id ON ai_recommendations(user_id);