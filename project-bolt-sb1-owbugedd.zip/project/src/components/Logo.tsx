interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  variant?: 'color' | 'white';
}

export function Logo({ size = 'md', variant = 'color' }: LogoProps) {
  const iconSize = size === 'sm' ? 28 : size === 'md' ? 36 : 48;
  const textSize = size === 'sm' ? 'text-base' : size === 'md' ? 'text-xl' : 'text-3xl';
  const subSize = size === 'sm' ? 'text-[9px]' : size === 'md' ? 'text-[10px]' : 'text-xs';

  const greenColor = variant === 'white' ? '#ffffff' : '#1a6b2e';
  const amberColor = variant === 'white' ? '#fbbf24' : '#d4960a';
  const blueColor = variant === 'white' ? '#93c5fd' : '#2d72d2';
  const textPrimary = variant === 'white' ? 'text-white' : 'text-green-900';
  const tagColor = variant === 'white' ? 'text-green-100' : 'text-neutral-500';


  return (
    <div className="flex items-center gap-2.5">
      {/* SVG Logo Mark */}
      <svg width={iconSize} height={iconSize} viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Outer ring */}
        <circle cx="40" cy="40" r="36" stroke={greenColor} strokeWidth="3.5" fill="none" opacity="0.25" />
        {/* Farm field lines */}
        <path d="M14 56 Q27 48 40 52 Q53 56 66 48" stroke={greenColor} strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M18 62 Q31 54 44 58 Q57 62 70 54" stroke={greenColor} strokeWidth="1.5" fill="none" strokeLinecap="round" opacity="0.5" />
        {/* Tractor body */}
        <rect x="22" y="38" width="28" height="16" rx="3" fill={greenColor} />
        {/* Tractor cab */}
        <rect x="34" y="30" width="14" height="12" rx="2.5" fill={greenColor} opacity="0.85" />
        {/* Tractor window */}
        <rect x="36" y="32" width="10" height="7" rx="1.5" fill={blueColor} opacity="0.7" />
        {/* Rear wheel */}
        <circle cx="30" cy="56" r="9" fill={amberColor} />
        <circle cx="30" cy="56" r="5.5" fill={greenColor} />
        <circle cx="30" cy="56" r="2" fill={amberColor} />
        {/* Front wheel */}
        <circle cx="46" cy="56" r="6" fill={amberColor} />
        <circle cx="46" cy="56" r="3.5" fill={greenColor} />
        <circle cx="46" cy="56" r="1.5" fill={amberColor} />
        {/* Gear icon top */}
        <circle cx="54" cy="24" r="7" fill={blueColor} opacity="0.9" />
        <path d="M54 19v-2M54 31v-2M59 22l1.4-1.4M47.6 29.4l1.4-1.4M61 24h2M49 24h-2M59 29.4l1.4 1.4M47.6 22l1.4 1.4" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="54" cy="24" r="3" fill="white" />
        {/* Handshake dots */}
        <circle cx="62" cy="36" r="2" fill={greenColor} />
        <circle cx="68" cy="30" r="1.5" fill={greenColor} opacity="0.6" />
        <circle cx="72" cy="38" r="1" fill={amberColor} opacity="0.7" />
        {/* Blue arc */}
        <path d="M60 16 Q74 28 68 50" stroke={blueColor} strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.7" />
      </svg>

      {/* Wordmark */}
      <div className="flex flex-col leading-none">
        <div className={`font-extrabold tracking-tight ${textSize}`}>
          <span className={textPrimary}>RENTO </span>
          <span style={{ color: variant === 'white' ? '#4cbb62' : '#2d8a3e' }}>KRISHISHARE</span>
        </div>
        {size !== 'sm' && (
          <span className={`${subSize} ${tagColor} font-medium tracking-wide mt-0.5`}>
            Rent Anything. Hire Anyone. Work Together.
          </span>
        )}
      </div>
    </div>
  );
}
