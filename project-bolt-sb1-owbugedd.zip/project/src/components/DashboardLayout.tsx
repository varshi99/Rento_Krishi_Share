import { type ReactNode, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Logo } from './Logo';
import {
  LayoutDashboard, Tractor, Users, Truck, CloudSun, Sprout, Calendar,
  LifeBuoy, LogOut, Menu, User, Wallet, Star, Settings,
  Share2, Brain, BarChart3, MapPin
} from 'lucide-react';
import { NotificationBell } from './NotificationBell';

const ROLE_LABELS: Record<string, string> = {
  farmer: 'Farmer',
  equipment_owner: 'Equipment Owner',
  worker: 'Worker',
  transport_provider: 'Transport Provider',
  admin: 'Admin',
};

const ROLE_ICONS: Record<string, typeof Sprout> = {
  farmer: Sprout,
  equipment_owner: Tractor,
  worker: Users,
  transport_provider: Truck,
  admin: Settings,
};

const NAV_ITEMS = [
  { path: '/dashboard', label: 'Overview', icon: LayoutDashboard, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
  { path: '/dashboard/equipment', label: 'Equipment', icon: Tractor, roles: ['farmer', 'equipment_owner', 'admin'] },
  { path: '/dashboard/workers', label: 'Workers', icon: Users, roles: ['farmer', 'worker', 'admin'] },
  { path: '/dashboard/transport', label: 'Transport', icon: Truck, roles: ['farmer', 'transport_provider', 'admin'] },
  { path: '/dashboard/bookings', label: 'Bookings', icon: Calendar, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
  { path: '/dashboard/shared-bookings', label: 'Shared Bookings', icon: Share2, roles: ['farmer', 'admin'] },
  { path: '/dashboard/transport-tracking', label: 'Live Tracking', icon: MapPin, roles: ['farmer', 'transport_provider', 'admin'] },
  { path: '/dashboard/weather', label: 'Weather', icon: CloudSun, roles: ['farmer', 'admin'] },
  { path: '/dashboard/crop-advisory', label: 'Crop Advisory', icon: Sprout, roles: ['farmer', 'admin'] },
  { path: '/dashboard/recommendations', label: 'AI Recommendations', icon: Brain, roles: ['farmer', 'admin'] },
  { path: '/dashboard/analytics', label: 'Analytics', icon: BarChart3, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
  { path: '/dashboard/notifications', label: 'Notifications', icon: Calendar, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
  { path: '/dashboard/payments', label: 'Payments', icon: Wallet, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
  { path: '/dashboard/reviews', label: 'Reviews', icon: Star, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
  { path: '/dashboard/support', label: 'Support', icon: LifeBuoy, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
  { path: '/dashboard/profile', label: 'Profile', icon: User, roles: ['farmer', 'equipment_owner', 'worker', 'transport_provider', 'admin'] },
];

export function DashboardLayout({ children }: { children: ReactNode }) {
  const { profile, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const role = profile?.role ?? 'farmer';
  const RoleIcon = ROLE_ICONS[role] ?? Sprout;
  const navItems = NAV_ITEMS.filter(item => item.roles.includes(role));

  function handleSignOut() {
    signOut();
    navigate('/');
  }

  return (
    <div className="min-h-screen bg-neutral-50 flex">
      {/* Sidebar */}
      <aside
        className={`fixed lg:sticky top-0 left-0 z-50 h-screen w-64 bg-green-950 text-white flex-shrink-0 flex flex-col transition-transform duration-200 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="p-5 border-b border-green-800">
          <Link to="/" onClick={() => setSidebarOpen(false)}>
            <Logo size="sm" variant="white" />
          </Link>
        </div>

        {/* User info */}
        <div className="p-4 border-b border-green-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-green-800 flex items-center justify-center">
              <RoleIcon className="w-5 h-5 text-green-400" />
            </div>
            <div className="min-w-0">
              <div className="font-semibold text-sm truncate">{profile?.full_name ?? 'User'}</div>
              <div className="text-xs text-green-300">{ROLE_LABELS[role]}</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  active
                    ? 'bg-green-800 text-white'
                    : 'text-green-100/80 hover:bg-green-900 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Sign out */}
        <div className="p-3 border-t border-green-800">
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-green-100/80 hover:bg-green-900 hover:text-white transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-white border-b border-neutral-200 px-4 sm:px-6 py-3 flex items-center justify-between">
          <button
            className="lg:hidden p-2 rounded-lg text-neutral-600 hover:bg-neutral-100"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="hidden lg:block">
            <h1 className="text-lg font-bold text-neutral-900">
              {navItems.find(i => i.path === location.pathname)?.label ?? 'Dashboard'}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <NotificationBell />
            <div className="w-9 h-9 rounded-full bg-green-100 flex items-center justify-center text-sm font-bold text-green-700">
              {profile?.full_name?.charAt(0).toUpperCase() ?? 'U'}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}
