import { Link } from 'react-router-dom';
import { Logo } from './Logo';
import { Tractor, Users, Truck, CloudSun, Sprout, LifeBuoy } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-green-950 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Logo size="md" variant="white" />
            <p className="mt-4 text-sm text-green-100/80 leading-relaxed">
              India's agriculture sharing platform. Connecting farmers with equipment, workers, and transport — all in one place.
            </p>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-sm font-semibold text-green-100 uppercase tracking-wider mb-4">Services</h3>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/equipment" className="text-green-100/80 hover:text-white transition-colors flex items-center gap-2"><Tractor className="w-3.5 h-3.5" /> Equipment Rental</Link></li>
              <li><Link to="/workers" className="text-green-100/80 hover:text-white transition-colors flex items-center gap-2"><Users className="w-3.5 h-3.5" /> Workforce</Link></li>
              <li><Link to="/transport" className="text-green-100/80 hover:text-white transition-colors flex items-center gap-2"><Truck className="w-3.5 h-3.5" /> Transport</Link></li>
              <li><Link to="/weather" className="text-green-100/80 hover:text-white transition-colors flex items-center gap-2"><CloudSun className="w-3.5 h-3.5" /> Weather</Link></li>
              <li><Link to="/crop-advisory" className="text-green-100/80 hover:text-white transition-colors flex items-center gap-2"><Sprout className="w-3.5 h-3.5" /> Crop Advisory</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-sm font-semibold text-green-100 uppercase tracking-wider mb-4">Company</h3>
            <ul className="space-y-2.5 text-sm">
              <li><Link to="/about" className="text-green-100/80 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="text-green-100/80 hover:text-white transition-colors">Contact</Link></li>
              <li><Link to="/support" className="text-green-100/80 hover:text-white transition-colors flex items-center gap-2"><LifeBuoy className="w-3.5 h-3.5" /> Support</Link></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-sm font-semibold text-green-100 uppercase tracking-wider mb-4">Stay Updated</h3>
            <p className="text-sm text-green-100/80 mb-3">Get farming tips and platform updates.</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 px-3 py-2 rounded-lg text-sm text-neutral-900 bg-white/95 border border-green-800 focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
              <button className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-sm font-semibold transition-colors">Subscribe</button>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-green-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-green-100/60">© 2026 Rento KrishiShare. All rights reserved.</p>
          <div className="flex gap-4 text-sm text-green-100/60">
            <Link to="/privacy" className="hover:text-white transition-colors">Privacy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
