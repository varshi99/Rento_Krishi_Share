import { useState, type FormEvent } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import {
  CreditCard, Check, Lock, IndianRupee, Smartphone, Receipt, X, Loader2, AlertCircle
} from 'lucide-react';

interface CheckoutModalProps {
  item: {
    name: string;
    type: 'equipment' | 'worker' | 'transport';
    dailyRate: number;
    days?: number;
    listingId?: string;
  };
  onClose: () => void;
  onSuccess: () => void;
}

export function CheckoutModal({ item, onClose, onSuccess }: CheckoutModalProps) {
  const { session } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card'>('upi');
  const [upiId, setUpiId] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [txnId, setTxnId] = useState('');

  const days = item.days ?? 1;
  const subtotal = item.dailyRate * days;
  const platformFee = Math.round(subtotal * 0.02);
  const tax = Math.round(subtotal * 0.05);
  const total = subtotal + platformFee + tax;

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (paymentMethod === 'upi' && !upiId.includes('@')) {
      setError('Please enter a valid UPI ID (e.g. name@upi)');
      setLoading(false);
      return;
    }
    if (paymentMethod === 'card' && cardNumber.replace(/\s/g, '').length < 12) {
      setError('Please enter a valid card number');
      setLoading(false);
      return;
    }

    try {
      // Step 1: Create a booking record
      const { data: booking, error: bookingError } = await supabase
        .from('bookings')
        .insert({
          booker_id: session!.user.id,
          listing_type: item.type,
          listing_id: item.listingId ?? null,
          start_date: new Date().toISOString().split('T')[0],
          end_date: new Date(Date.now() + days * 86400000).toISOString().split('T')[0],
          total_cost: total,
          status: 'pending',
        })
        .select()
        .single();

      if (bookingError) throw new Error('Failed to create booking: ' + bookingError.message);

      // Step 2: Create a pending payment record
      const { data: payment, error: paymentError } = await supabase
        .from('payments')
        .insert({
          user_id: session!.user.id,
          booking_id: booking.id,
          amount: total,
          currency: 'INR',
          status: 'pending',
          listing_type: item.type,
          listing_name: item.name,
          payment_method: paymentMethod,
        })
        .select()
        .single();

      if (paymentError) throw new Error('Failed to create payment record: ' + paymentError.message);

      // Step 3: Call the Razorpay edge function to create an order
      const { data: { session: currentSession } } = await supabase.auth.getSession();
      const accessToken = currentSession?.access_token ?? import.meta.env.VITE_SUPABASE_ANON_KEY;

      const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/razorpay-checkout`;
      const orderResponse = await fetch(functionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          amount: total * 100, // Razorpay expects paise
          currency: 'INR',
          description: `${item.type} booking - ${item.name} (${days} day${days > 1 ? 's' : ''})`,
          listing_type: item.type,
          listing_name: item.name,
          user_id: session!.user.id,
        }),
      });

      const orderData = await orderResponse.json().catch(() => null);

      if (!orderResponse.ok) {
        const msg = orderData?.error ?? `Payment gateway error (${orderResponse.status}). Please try again.`;
        throw new Error(msg);
      }

      if (orderData.error) {
        throw new Error(orderData.error);
      }

      // Step 4: If Razorpay is configured, open the real checkout
      if (orderData.key_id && orderData.order_id && !orderData.simulated) {
        await openRazorpayCheckout(orderData, payment.id, booking.id, total);
      } else {
        // Simulated mode (no Razorpay keys configured)
        await simulatePayment(payment.id, booking.id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Payment failed. Please try again.');
      setLoading(false);
    }
  }

  async function openRazorpayCheckout(orderData: any, paymentId: string, bookingId: string, amount: number) {
    // Load Razorpay script
    const existingScript = document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]');
    if (existingScript) existingScript.remove();

    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;

    script.onload = () => {
      const options = {
        key: orderData.key_id,
        amount: orderData.amount,
        currency: orderData.currency,
        name: 'KrishiShare',
        description: `${item.type} booking - ${item.name}`,
        order_id: orderData.order_id,
        prefill: {
          name: cardName || '',
          email: session?.user?.email || '',
        },
        theme: { color: '#15803d' },
        handler: async (response: any) => {
          // Payment succeeded — verify and update records
          await supabase.from('payments').update({
            status: 'completed',
            razorpay_order_id: response.razorpay_order_id,
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_signature: response.razorpay_signature,
            updated_at: new Date().toISOString(),
          }).eq('id', paymentId);

          await supabase.from('bookings').update({
            status: 'confirmed',
            updated_at: new Date().toISOString(),
          }).eq('id', bookingId);

          setTxnId(response.razorpay_payment_id);
          setSuccess(true);
          setLoading(false);
          setTimeout(() => { onSuccess(); onClose(); }, 2500);
        },
        modal: {
          ondismiss: () => {
            setError('Payment cancelled. You can retry from the bookings page.');
            setLoading(false);
          },
        },
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.on('payment.failed', async (response: any) => {
        await supabase.from('payments').update({
          status: 'failed',
          razorpay_payment_id: response.error.metadata?.payment_id ?? null,
          updated_at: new Date().toISOString(),
        }).eq('id', paymentId);
        setError(response.error.description || 'Payment failed. Please try again.');
        setLoading(false);
      });
      rzp.open();
    };

    script.onerror = () => {
      // Fallback to simulated if script fails to load
      simulatePayment(paymentId, bookingId);
    };

    document.body.appendChild(script);
  }

  async function simulatePayment(paymentId: string, bookingId: string) {
    // Simulate payment processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mark payment as completed
    await supabase.from('payments').update({
      status: 'completed',
      razorpay_order_id: `order_sim_${Date.now()}`,
      razorpay_payment_id: `pay_sim_${Date.now()}`,
      updated_at: new Date().toISOString(),
    }).eq('id', paymentId);

    // Confirm the booking
    await supabase.from('bookings').update({
      status: 'confirmed',
      updated_at: new Date().toISOString(),
    }).eq('id', bookingId);

    setTxnId(`pay_sim_${Date.now().toString().slice(-10)}`);
    setSuccess(true);
    setLoading(false);
    setTimeout(() => { onSuccess(); onClose(); }, 2500);
  }

  if (success) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-xl font-bold text-neutral-900">Payment Successful!</h3>
          <p className="text-sm text-neutral-500 mt-2">Your booking for {item.name} has been confirmed.</p>
          <div className="mt-4 p-3 rounded-xl bg-neutral-50">
            <div className="text-xs text-neutral-500">Transaction ID</div>
            <div className="font-mono text-sm font-bold text-neutral-900">{txnId}</div>
          </div>
          <div className="mt-3 text-lg font-extrabold text-green-700">₹{total.toLocaleString('en-IN')}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900">Checkout</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              {error}
            </div>
          )}

          {/* Order summary */}
          <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <Receipt className="w-5 h-5 text-green-700" />
              </div>
              <div>
                <div className="font-semibold text-neutral-900">{item.name}</div>
                <div className="text-xs text-neutral-500 capitalize">{item.type} · {days} day{days > 1 ? 's' : ''}</div>
              </div>
            </div>
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-neutral-500">
                <span>Base rate (₹{item.dailyRate} × {days})</span>
                <span>₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-neutral-500">
                <span>Platform fee (2%)</span>
                <span>₹{platformFee.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-neutral-500">
                <span>GST (5%)</span>
                <span>₹{tax.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between font-bold text-neutral-900 pt-2 border-t border-neutral-200">
                <span>Total</span>
                <span className="text-green-700">₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>

          {/* Payment method tabs */}
          <div>
            <label className="label">Payment Method</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setPaymentMethod('upi')}
                className={`p-4 rounded-xl border-2 text-center transition-all ${paymentMethod === 'upi' ? 'border-green-600 bg-green-50' : 'border-neutral-200 hover:border-green-300'}`}
              >
                <Smartphone className={`w-6 h-6 mx-auto mb-2 ${paymentMethod === 'upi' ? 'text-green-700' : 'text-neutral-400'}`} />
                <div className={`text-sm font-semibold ${paymentMethod === 'upi' ? 'text-green-800' : 'text-neutral-600'}`}>UPI</div>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-4 rounded-xl border-2 text-center transition-all ${paymentMethod === 'card' ? 'border-green-600 bg-green-50' : 'border-neutral-200 hover:border-green-300'}`}
              >
                <CreditCard className={`w-6 h-6 mx-auto mb-2 ${paymentMethod === 'card' ? 'text-green-700' : 'text-neutral-400'}`} />
                <div className={`text-sm font-semibold ${paymentMethod === 'card' ? 'text-green-800' : 'text-neutral-600'}`}>Card</div>
              </button>
            </div>
          </div>

          {/* UPI form */}
          {paymentMethod === 'upi' && (
            <div>
              <label className="label">UPI ID</label>
              <input
                type="text"
                required
                value={upiId}
                onChange={e => setUpiId(e.target.value)}
                placeholder="yourname@upi"
                className="input-field"
              />
              <p className="text-xs text-neutral-400 mt-1">Enter your UPI ID to pay via any UPI app</p>
            </div>
          )}

          {/* Card form */}
          {paymentMethod === 'card' && (
            <div className="space-y-4">
              <div>
                <label className="label">Card Number</label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                  <input
                    type="text"
                    required
                    value={cardNumber}
                    onChange={e => setCardNumber(e.target.value.replace(/(\d{4})(?=\d)/g, '$1 ').substring(0, 19))}
                    placeholder="1234 5678 9012 3456"
                    className="input-field pl-10"
                  />
                </div>
              </div>
              <div>
                <label className="label">Cardholder Name</label>
                <input
                  type="text"
                  required
                  value={cardName}
                  onChange={e => setCardName(e.target.value)}
                  placeholder="Name on card"
                  className="input-field"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="label">Expiry</label>
                  <input
                    type="text"
                    required
                    value={cardExpiry}
                    onChange={e => setCardExpiry(e.target.value.replace(/(\d{2})(?=\d)/g, '$1/').substring(0, 5))}
                    placeholder="MM/YY"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label">CVV</label>
                  <input
                    type="password"
                    required
                    value={cardCvv}
                    onChange={e => setCardCvv(e.target.value.substring(0, 3))}
                    placeholder="123"
                    className="input-field"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Security badge */}
          <div className="flex items-center justify-center gap-2 text-xs text-neutral-400">
            <Lock className="w-3.5 h-3.5" />
            <span>Powered by Razorpay · 256-bit encrypted</span>
          </div>

          {/* Pay button */}
          <button type="submit" disabled={loading} className="btn-primary w-full justify-center disabled:opacity-60">
            {loading ? (
              <><Loader2 className="w-5 h-5 animate-spin" /> Processing payment…</>
            ) : (
              <><IndianRupee className="w-5 h-5" /> Pay ₹{total.toLocaleString('en-IN')}</>
            )}
          </button>

          <p className="text-center text-xs text-neutral-400">
            By proceeding, you agree to our Terms & Refund Policy
          </p>
        </form>
      </div>
    </div>
  );
}
