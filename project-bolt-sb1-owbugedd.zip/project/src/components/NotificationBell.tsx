import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Bell, Check, X, Clock } from 'lucide-react';
import { useNotifications } from '../hooks/useNotifications';

const TYPE_ICONS: Record<string, string> = {
  booking: '📅',
  payment: '💳',
  weather: '🌤️',
  transport: '🚚',
  system: '⚙️',
  review: '⭐',
  shared_booking: '👥',
};

const TYPE_COLORS: Record<string, string> = {
  booking: 'bg-green-100 text-green-700',
  payment: 'bg-amber-100 text-amber-700',
  weather: 'bg-blue-100 text-blue-700',
  transport: 'bg-blue-100 text-blue-700',
  system: 'bg-neutral-100 text-neutral-700',
  review: 'bg-amber-100 text-amber-700',
  shared_booking: 'bg-green-100 text-green-700',
};

function timeAgo(dateString: string): string {
  const diff = Date.now() - new Date(dateString).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export function NotificationBell() {
  const { notifications, unreadCount, markAsRead, markAllAsRead, deleteNotification } = useNotifications();
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="relative p-2 rounded-lg text-neutral-600 hover:bg-neutral-100 transition-colors"
        aria-label="Notifications"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-fade-in">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-neutral-200 z-50 animate-fade-in max-h-[480px] flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-neutral-200">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-neutral-900">Notifications</h3>
              {unreadCount > 0 && (
                <span className="badge bg-red-100 text-red-700">{unreadCount} new</span>
              )}
            </div>
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="text-xs font-semibold text-green-700 hover:text-green-800 flex items-center gap-1"
              >
                <Check className="w-3.5 h-3.5" /> Mark all read
              </button>
            )}
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="py-12 text-center">
                <Bell className="w-10 h-10 mx-auto text-neutral-300 mb-2" />
                <p className="text-sm text-neutral-400">No notifications yet</p>
              </div>
            ) : (
              <div className="divide-y divide-neutral-100">
                {notifications.slice(0, 20).map((n) => (
                  <div
                    key={n.id}
                    className={`p-4 hover:bg-neutral-50 transition-colors group ${!n.is_read ? 'bg-green-50/50' : ''}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 text-base ${TYPE_COLORS[n.type] ?? TYPE_COLORS.system}`}>
                        {TYPE_ICONS[n.type] ?? '🔔'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="font-semibold text-sm text-neutral-900">{n.title}</div>
                            <div className="text-xs text-neutral-500 mt-0.5">{n.message}</div>
                          </div>
                          {!n.is_read && <div className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0 mt-1.5" />}
                        </div>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-neutral-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {timeAgo(n.created_at)}
                          </span>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            {!n.is_read && (
                              <button
                                onClick={() => markAsRead(n.id)}
                                className="p-1 rounded text-neutral-400 hover:text-green-700 hover:bg-green-50"
                                title="Mark as read"
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              onClick={() => deleteNotification(n.id)}
                              className="p-1 rounded text-neutral-400 hover:text-red-600 hover:bg-red-50"
                              title="Delete"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="p-3 border-t border-neutral-200">
              <Link
                to="/dashboard/notifications"
                onClick={() => setOpen(false)}
                className="block text-center text-sm font-semibold text-green-700 hover:text-green-800 py-1"
              >
                View all notifications
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
