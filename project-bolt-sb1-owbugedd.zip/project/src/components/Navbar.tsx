import { Link } from 'react-router-dom';
import { Logo } from './Logo';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Navbar() {
  const { session, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-neutral-200 shadow-nav">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex-shrink-0">
            <Logo size="md" />
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-6">
            <Link to="/equipment" className="text-sm font-medium text-neutral-700 hover:text-green-700 transition-colors">Equipment</Link>
            <Link to="/workers" className="text-sm font-medium text-neutral-700 hover:text-green-700 transition-colors">Workers</Link>
            <Link to="/transport" className="text-sm font-medium text-neutral-700 hover:text-green-700 transition-colors">Transport</Link>
            <Link to="/weather" className="text-sm font-medium text-neutral-700 hover:text-green-700 transition-colors">Weather</Link>
            <Link to="/crop-advisory" className="text-sm font-medium text-neutral-700 hover:text-green-700 transition-colors">Crop Advisory</Link>
          </div>

          {/* Auth buttons */}
          <div className="hidden md:flex items-center gap-3">
            {session ? (
              <>
                <Link to="/dashboard" className="btn-secondary text-sm py-2 px-4">
                  <LayoutDashboard className="w-4 h-4" />
                  Dashboard
                </Link>
                <button
                  onClick={signOut}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-sm font-semibold text-neutral-700 hover:text-green-700 transition-colors px-4 py-2">
                  Sign In
                </Link>
                <Link to="/register" className="btn-primary text-sm py-2 px-4">
                  Get Started
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2 rounded-lg text-neutral-700 hover:bg-neutral-100"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-neutral-200 py-4 space-y-2 animate-fade-in">
            <Link to="/equipment" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-neutral-700 hover:bg-green-50 hover:text-green-700">Equipment</Link>
            <Link to="/workers" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-neutral-700 hover:bg-green-50 hover:text-green-700">Workers</Link>
            <Link to="/transport" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-neutral-700 hover:bg-green-50 hover:text-green-700">Transport</Link>
            <Link to="/weather" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-neutral-700 hover:bg-green-50 hover:text-green-700">Weather</Link>
            <Link to="/crop-advisory" onClick={() => setMobileOpen(false)} className="block px-3 py-2 rounded-lg text-sm font-medium text-neutral-700 hover:bg-green-50 hover:text-green-700">Crop Advisory</Link>
            <div className="pt-2 border-t border-neutral-200">
              {session ? (
                <div className="flex flex-col gap-2">
                  <Link to="/dashboard" onClick={() => setMobileOpen(false)} className="btn-secondary text-sm py-2 justify-center">Dashboard</Link>
                  <button onClick={() => { signOut(); setMobileOpen(false); }} className="text-sm font-semibold text-neutral-600 px-4 py-2 text-left">Sign Out</button>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  <Link to="/login" onClick={() => setMobileOpen(false)} className="text-sm font-semibold text-neutral-700 px-4 py-2">Sign In</Link>
                  <Link to="/register" onClick={() => setMobileOpen(false)} className="btn-primary text-sm py-2 justify-center">Get Started</Link>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
