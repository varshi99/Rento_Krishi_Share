import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { type ReactNode } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { DashboardLayout } from './components/DashboardLayout';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { DashboardPage } from './pages/DashboardPage';
import { EquipmentPage } from './pages/EquipmentPage';
import { WorkersPage } from './pages/WorkersPage';
import { TransportPage } from './pages/TransportPage';
import { WeatherPage } from './pages/WeatherPage';
import { CropAdvisoryPage } from './pages/CropAdvisoryPage';
import { BookingsPage } from './pages/BookingsPage';
import { PaymentsPage } from './pages/PaymentsPage';
import { ReviewsPage } from './pages/ReviewsPage';
import { SupportPage } from './pages/SupportPage';
import { ProfilePage } from './pages/ProfilePage';
import { NotificationsPage } from './pages/NotificationsPage';
import { SharedBookingPage } from './pages/SharedBookingPage';
import { RecommendationsPage } from './pages/RecommendationsPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { TransportTrackingPage } from './pages/TransportTrackingPage';
import {
  PublicEquipmentPage, PublicWorkersPage, PublicTransportPage,
  PublicWeatherPage, PublicCropAdvisoryPage
} from './pages/PublicPages';

function ProtectedRoute({ children }: { children: ReactNode }) {
  const { session, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-neutral-400">Loading...</div>
      </div>
    );
  }

  if (!session) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <DashboardLayout>{children}</DashboardLayout>;
}

function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      {children}
      <Footer />
    </div>
  );
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<PublicLayout><LandingPage /></PublicLayout>} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      {/* Public pages */}
      <Route path="/equipment" element={<PublicEquipmentPage />} />
      <Route path="/workers" element={<PublicWorkersPage />} />
      <Route path="/transport" element={<PublicTransportPage />} />
      <Route path="/weather" element={<PublicWeatherPage />} />
      <Route path="/crop-advisory" element={<PublicCropAdvisoryPage />} />
      <Route path="/shared-bookings" element={<PublicLayout><SharedBookingPage /></PublicLayout>} />

      {/* Dashboard (protected) */}
      <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
      <Route path="/dashboard/equipment" element={<ProtectedRoute><EquipmentPage /></ProtectedRoute>} />
      <Route path="/dashboard/workers" element={<ProtectedRoute><WorkersPage /></ProtectedRoute>} />
      <Route path="/dashboard/transport" element={<ProtectedRoute><TransportPage /></ProtectedRoute>} />
      <Route path="/dashboard/bookings" element={<ProtectedRoute><BookingsPage /></ProtectedRoute>} />
      <Route path="/dashboard/weather" element={<ProtectedRoute><WeatherPage /></ProtectedRoute>} />
      <Route path="/dashboard/crop-advisory" element={<ProtectedRoute><CropAdvisoryPage /></ProtectedRoute>} />
      <Route path="/dashboard/payments" element={<ProtectedRoute><PaymentsPage /></ProtectedRoute>} />
      <Route path="/dashboard/reviews" element={<ProtectedRoute><ReviewsPage /></ProtectedRoute>} />
      <Route path="/dashboard/support" element={<ProtectedRoute><SupportPage /></ProtectedRoute>} />
      <Route path="/dashboard/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
      <Route path="/dashboard/notifications" element={<ProtectedRoute><NotificationsPage /></ProtectedRoute>} />
      <Route path="/dashboard/shared-bookings" element={<ProtectedRoute><SharedBookingPage /></ProtectedRoute>} />
      <Route path="/dashboard/recommendations" element={<ProtectedRoute><RecommendationsPage /></ProtectedRoute>} />
      <Route path="/dashboard/analytics" element={<ProtectedRoute><AnalyticsPage /></ProtectedRoute>} />
      <Route path="/dashboard/transport-tracking" element={<ProtectedRoute><TransportTrackingPage /></ProtectedRoute>} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
