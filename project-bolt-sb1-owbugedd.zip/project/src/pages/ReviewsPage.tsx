import { Star } from 'lucide-react';

export function ReviewsPage() {
  const reviews = [
    { id: '1', reviewer: 'Rajesh Kumar', type: 'equipment', name: 'Mahindra Tractor', rating: 5, comment: 'Excellent tractor, very well maintained. Delivered on time!', date: '2026-07-12' },
    { id: '2', reviewer: 'Sunita Devi', type: 'worker', name: 'Harvesting Worker', rating: 4, comment: 'Hard working and punctual. Would hire again.', date: '2026-07-10' },
    { id: '3', reviewer: 'Amit Singh', type: 'transport', name: 'Mini Truck', rating: 5, comment: 'Fast delivery and careful handling of goods.', date: '2026-07-08' },
    { id: '4', reviewer: 'Priya Sharma', type: 'equipment', name: 'Rotavator', rating: 3, comment: 'Good equipment but arrived a day late.', date: '2026-07-05' },
  ];

  const avgRating = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-extrabold text-neutral-900">Reviews & Feedback</h2>
        <p className="text-sm text-neutral-500 mt-1">See what others are saying about your services</p>
      </div>

      {/* Summary */}
      <div className="card p-6 flex items-center gap-6">
        <div className="text-center">
          <div className="text-4xl font-extrabold text-neutral-900">{avgRating}</div>
          <div className="flex items-center gap-0.5 mt-1">
            {[1, 2, 3, 4, 5].map(i => <Star key={i} className={`w-4 h-4 ${i <= Math.round(parseFloat(avgRating)) ? 'text-amber-400 fill-current' : 'text-neutral-200'}`} />)}
          </div>
          <div className="text-xs text-neutral-500 mt-1">{reviews.length} reviews</div>
        </div>
        <div className="flex-1 space-y-2">
          {[5, 4, 3, 2, 1].map(star => {
            const count = reviews.filter(r => r.rating === star).length;
            const pct = (count / reviews.length) * 100;
            return (
              <div key={star} className="flex items-center gap-2 text-sm">
                <span className="w-12 text-neutral-500">{star} star</span>
                <div className="flex-1 h-2 rounded-full bg-neutral-100 overflow-hidden">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${pct}%` }} />
                </div>
                <span className="w-8 text-right text-neutral-500">{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Reviews list */}
      <div className="space-y-3">
        {reviews.map(r => (
          <div key={r.id} className="card p-5">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center font-bold text-green-700 flex-shrink-0">
                {r.reviewer.charAt(0)}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-neutral-900">{r.reviewer}</div>
                    <div className="text-xs text-neutral-500 capitalize">{r.type} · {r.name}</div>
                  </div>
                  <div className="text-xs text-neutral-400">{r.date}</div>
                </div>
                <div className="flex items-center gap-0.5 mt-2">
                  {[1, 2, 3, 4, 5].map(i => <Star key={i} className={`w-4 h-4 ${i <= r.rating ? 'text-amber-400 fill-current' : 'text-neutral-200'}`} />)}
                </div>
                <p className="text-sm text-neutral-600 mt-2">{r.comment}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
