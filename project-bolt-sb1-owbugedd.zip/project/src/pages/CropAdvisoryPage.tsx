import { Sprout, Beaker, Bug, Calendar, Leaf, Sun, Snowflake } from 'lucide-react';

export function CropAdvisoryPage() {
  const crops = [
    { name: 'Rice', season: 'Kharif', icon: Sprout, water: 'High', temp: '25-35°C', growth: '120 days' },
    { name: 'Wheat', season: 'Rabi', icon: Leaf, water: 'Medium', temp: '10-25°C', growth: '140 days' },
    { name: 'Cotton', season: 'Kharif', icon: Sprout, water: 'Medium', temp: '21-30°C', growth: '180 days' },
    { name: 'Sugarcane', season: 'Annual', icon: Sprout, water: 'High', temp: '20-35°C', growth: '365 days' },
    { name: 'Maize', season: 'Kharif', icon: Sprout, water: 'Medium', temp: '18-32°C', growth: '90 days' },
    { name: 'Pulses', season: 'Both', icon: Leaf, water: 'Low', temp: '15-30°C', growth: '100 days' },
  ];

  const fertilizers = [
    { crop: 'Rice', npk: 'N:P:K = 80:40:40', notes: 'Apply nitrogen in 3 splits at planting, tillering, and panicle initiation.' },
    { crop: 'Wheat', npk: 'N:P:K = 120:60:40', notes: 'Basal application of P and K. Top-dress nitrogen at first irrigation.' },
    { crop: 'Cotton', npk: 'N:P:K = 60:30:30', notes: 'Apply farmyard manure. Split nitrogen at 30 and 60 days after sowing.' },
    { crop: 'Sugarcane', npk: 'N:P:K = 150:75:75', notes: 'Heavy feeder. Apply organic matter at planting, N in splits through the season.' },
  ];

  const pests = [
    { pest: 'Stem Borer', crop: 'Rice', symptom: 'Dead heart symptoms in seedlings', control: 'Apply Carbofuran granules at nursery stage. Use light traps.' },
    { pest: 'Aphids', crop: 'Cotton, Wheat', symptom: 'Curling leaves, sticky honeydew', control: 'Spray Neem oil 5%. Introduce ladybugs as biological control.' },
    { pest: 'Bollworm', crop: 'Cotton', symptom: 'Holes in bolls, damaged squares', control: 'Use Bt cotton varieties. Install pheromone traps.' },
    { pest: 'Termites', crop: 'All crops', symptom: 'Damaged roots, lodging', control: 'Apply Chlorpyriphos in soil before sowing. Use well-decomposed manure.' },
  ];

  const seasonalAdvice = [
    { season: 'Kharif (Jun-Oct)', icon: Sun, crops: 'Rice, Cotton, Maize, Pulses', advice: 'Ensure proper drainage. Monitor for pest outbreaks after rainfall. Use weather alerts for spraying schedules.' },
    { season: 'Rabi (Nov-Mar)', icon: Snowflake, crops: 'Wheat, Mustard, Gram, Peas', advice: 'Irrigate at critical stages: crown root initiation, tillering, flowering. Apply first irrigation 21 days after sowing.' },
    { season: 'Zaid (Apr-Jun)', icon: Sun, crops: 'Watermelon, Cucumber, Fodder', advice: 'Use drip irrigation. Mulch to conserve moisture. Provide shade for sensitive crops.' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-extrabold text-neutral-900">Crop Advisory</h2>
        <p className="text-sm text-neutral-500 mt-1">Expert guidance on crops, fertilizers, pest management, and seasonal practices</p>
      </div>

      {/* Crop Suggestions */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2"><Sprout className="w-5 h-5 text-green-700" /> Crop Suggestions</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {crops.map((c) => {
            const Icon = c.icon;
            return (
              <div key={c.name} className="p-4 rounded-xl border border-neutral-200 hover:border-green-300 hover:bg-green-50/50 transition-colors">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center"><Icon className="w-5 h-5 text-green-700" /></div>
                  <div>
                    <div className="font-bold text-neutral-900">{c.name}</div>
                    <div className="text-xs text-neutral-500">{c.season} Season</div>
                  </div>
                </div>
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between"><span className="text-neutral-500">Water Need</span><span className="font-semibold text-neutral-700">{c.water}</span></div>
                  <div className="flex justify-between"><span className="text-neutral-500">Temperature</span><span className="font-semibold text-neutral-700">{c.temp}</span></div>
                  <div className="flex justify-between"><span className="text-neutral-500">Growth Period</span><span className="font-semibold text-neutral-700">{c.growth}</span></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Fertilizer Recommendations */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2"><Beaker className="w-5 h-5 text-amber-600" /> Fertilizer Recommendations</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-200">
                <th className="text-left py-3 px-4 font-semibold text-neutral-700">Crop</th>
                <th className="text-left py-3 px-4 font-semibold text-neutral-700">NPK Ratio (kg/ha)</th>
                <th className="text-left py-3 px-4 font-semibold text-neutral-700">Application Notes</th>
              </tr>
            </thead>
            <tbody>
              {fertilizers.map((f, i) => (
                <tr key={i} className="border-b border-neutral-100 hover:bg-neutral-50">
                  <td className="py-3 px-4 font-semibold text-neutral-900">{f.crop}</td>
                  <td className="py-3 px-4"><span className="badge bg-green-100 text-green-700">{f.npk}</span></td>
                  <td className="py-3 px-4 text-neutral-600">{f.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pest Management */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2"><Bug className="w-5 h-5 text-red-600" /> Pest Management Tips</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          {pests.map((p, i) => (
            <div key={i} className="p-4 rounded-xl border border-neutral-200">
              <div className="flex items-center justify-between mb-2">
                <div className="font-bold text-neutral-900">{p.pest}</div>
                <span className="badge bg-red-50 text-red-700 border border-red-200">{p.crop}</span>
              </div>
              <div className="text-sm text-neutral-600 mb-2"><span className="font-semibold">Symptoms:</span> {p.symptom}</div>
              <div className="text-sm text-neutral-600"><span className="font-semibold">Control:</span> {p.control}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Seasonal Advice */}
      <div>
        <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2"><Calendar className="w-5 h-5 text-blue-700" /> Seasonal Advice</h3>
        <div className="grid lg:grid-cols-3 gap-5">
          {seasonalAdvice.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={i} className="card p-6">
                <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-4"><Icon className="w-6 h-6 text-blue-700" /></div>
                <h4 className="font-bold text-neutral-900">{s.season}</h4>
                <div className="text-sm text-green-700 font-semibold mt-1">{s.crops}</div>
                <p className="text-sm text-neutral-600 mt-2 leading-relaxed">{s.advice}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
