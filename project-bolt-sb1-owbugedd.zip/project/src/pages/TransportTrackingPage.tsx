import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase, type TransportTracking } from '../lib/supabase';
import {
  Truck, MapPin, Clock, Package, CheckCircle,
  Plus, X, Route, AlertCircle
} from 'lucide-react';

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: typeof Truck; step: number }> = {
  pending: { label: 'Pending Pickup', color: 'bg-amber-100 text-amber-700', icon: Clock, step: 0 },
  picked_up: { label: 'Picked Up', color: 'bg-blue-100 text-blue-700', icon: Package, step: 1 },
  in_transit: { label: 'In Transit', color: 'bg-blue-100 text-blue-700', icon: Truck, step: 2 },
  delivered: { label: 'Delivered', color: 'bg-green-100 text-green-700', icon: CheckCircle, step: 3 },
  cancelled: { label: 'Cancelled', color: 'bg-red-100 text-red-700', icon: AlertCircle, step: -1 },
};

const TRACKING_STEPS = ['Pending', 'Picked Up', 'In Transit', 'Delivered'];

export function TransportTrackingPage() {
  const { profile } = useAuth();
  const [trackingRecords, setTrackingRecords] = useState<TransportTracking[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTracking, setSelectedTracking] = useState<TransportTracking | null>(null);
  const [showUpdate, setShowUpdate] = useState(false);

  const loadTracking = useCallback(async () => {
    const { data, error } = await supabase
      .from('transport_tracking')
      .select('*')
      .order('updated_at', { ascending: false });

    if (error) console.error(error);
    setTrackingRecords(data as TransportTracking[] ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadTracking();

    const channel = supabase
      .channel('transport-tracking-channel')
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'transport_tracking' },
        () => loadTracking()
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [loadTracking]);

  const isProvider = profile?.role === 'transport_provider' || profile?.role === 'admin';

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Live Transport Tracking</h2>
          <p className="text-sm text-neutral-500 mt-1">Track your deliveries in real-time with live status updates</p>
        </div>
        {isProvider && trackingRecords.length > 0 && (
          <button onClick={() => setShowUpdate(true)} className="btn-primary">
            <Plus className="w-5 h-5" /> Add Tracking Update
          </button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading tracking data...</div>
      ) : trackingRecords.length === 0 ? (
        <div className="card p-12 text-center">
          <Truck className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No active deliveries</h3>
          <p className="text-sm text-neutral-500 mt-1">Transport bookings will appear here once tracking is initiated.</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Tracking list */}
          <div className="lg:col-span-1 space-y-3">
            {trackingRecords.map((t) => {
              const config = STATUS_CONFIG[t.status] ?? STATUS_CONFIG.pending;
              const Icon = config.icon;
              const isSelected = selectedTracking?.id === t.id;
              return (
                <div
                  key={t.id}
                  onClick={() => setSelectedTracking(t)}
                  className={`card p-4 cursor-pointer transition-all ${isSelected ? 'ring-2 ring-green-500 border-green-300' : 'hover:border-green-200'}`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${config.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm text-neutral-900">Booking #{t.booking_id.slice(0, 8)}</div>
                      <div className="text-xs text-neutral-500 mt-0.5">{config.label}</div>
                      {t.current_location && (
                        <div className="flex items-center gap-1 text-xs text-neutral-400 mt-1">
                          <MapPin className="w-3 h-3" /> {t.current_location}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Map / Detail view */}
          <div className="lg:col-span-2">
            {selectedTracking ? (
              <TrackingDetail tracking={selectedTracking} isProvider={isProvider} onUpdate={loadTracking} />
            ) : (
              <div className="card p-12 text-center">
                <Route className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
                <h3 className="text-lg font-bold text-neutral-900">Select a delivery to track</h3>
                <p className="text-sm text-neutral-500 mt-1">Click on a delivery from the list to view live tracking details.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {showUpdate && <UpdateTrackingModal onClose={() => { setShowUpdate(false); loadTracking(); }} />}
    </div>
  );
}

function TrackingDetail({ tracking, isProvider, onUpdate }: { tracking: TransportTracking; isProvider: boolean; onUpdate: () => void }) {
  const config = STATUS_CONFIG[tracking.status] ?? STATUS_CONFIG.pending;
  const currentStep = config.step;

  return (
    <div className="card overflow-hidden">
      {/* Map visualization */}
      <div className="relative h-64 bg-gradient-to-br from-green-50 via-blue-50 to-green-50 overflow-hidden">
        {/* Grid pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#2d8a3e" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>

        {/* Route line */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 256" preserveAspectRatio="none">
          <path d="M 60 200 Q 150 100 200 130 T 340 60" stroke="#2d72d2" strokeWidth="3" fill="none" strokeDasharray="8 4" opacity="0.6" />
        </svg>

        {/* Pickup point */}
        <div className="absolute left-[12%] bottom-[20%] flex flex-col items-center">
          <div className="w-8 h-8 rounded-full bg-green-600 border-2 border-white shadow-md flex items-center justify-center">
            <Package className="w-4 h-4 text-white" />
          </div>
          <span className="text-xs font-semibold text-neutral-700 mt-1 bg-white/80 px-1.5 rounded">Pickup</span>
        </div>

        {/* Delivery point */}
        <div className="absolute right-[12%] top-[20%] flex flex-col items-center">
          <div className="w-8 h-8 rounded-full bg-red-500 border-2 border-white shadow-md flex items-center justify-center">
            <MapPin className="w-4 h-4 text-white" />
          </div>
          <span className="text-xs font-semibold text-neutral-700 mt-1 bg-white/80 px-1.5 rounded">Destination</span>
        </div>

        {/* Truck icon - positioned based on status */}
        <div
          className="absolute transition-all duration-1000 ease-in-out"
          style={{
            left: currentStep >= 3 ? '82%' : currentStep === 2 ? '50%' : currentStep === 1 ? '25%' : '12%',
            top: currentStep >= 3 ? '20%' : currentStep === 2 ? '45%' : currentStep === 1 ? '55%' : '70%',
          }}
        >
          <div className="relative">
            {currentStep === 2 && (
              <span className="absolute inset-0 animate-ping rounded-full bg-blue-400 opacity-30" />
            )}
            <div className="w-10 h-10 rounded-full bg-blue-600 border-2 border-white shadow-lg flex items-center justify-center">
              <Truck className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>

        {/* Status badge */}
        <div className="absolute top-4 left-4">
          <span className={`badge ${config.color} shadow-sm`}>{config.label}</span>
        </div>

        {/* ETA */}
        {tracking.estimated_arrival && currentStep < 3 && (
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 shadow-sm">
            <div className="text-xs text-neutral-500">ETA</div>
            <div className="text-sm font-bold text-neutral-900">
              {new Date(tracking.estimated_arrival).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>
        )}
      </div>

      {/* Tracking details */}
      <div className="p-6">
        {/* Progress steps */}
        <div className="mb-6">
          <div className="flex items-center justify-between relative">
            {/* Progress line */}
            <div className="absolute top-5 left-0 right-0 h-1 bg-neutral-100 rounded-full" />
            <div
              className="absolute top-5 left-0 h-1 bg-green-500 rounded-full transition-all duration-500"
              style={{ width: `${(currentStep / 3) * 100}%` }}
            />
            {TRACKING_STEPS.map((step, i) => {
              const isCompleted = i <= currentStep && currentStep >= 0;
              const isCurrent = i === currentStep;
              return (
                <div key={i} className="relative z-10 flex flex-col items-center">
                  <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all ${
                    isCompleted ? 'bg-green-500 border-green-500 text-white' : 'bg-white border-neutral-200 text-neutral-400'
                  } ${isCurrent ? 'ring-4 ring-green-100' : ''}`}>
                    {isCompleted ? <CheckCircle className="w-5 h-5" /> : <span className="text-sm font-bold">{i + 1}</span>}
                  </div>
                  <span className={`text-xs mt-2 font-semibold ${isCompleted ? 'text-neutral-900' : 'text-neutral-400'}`}>{step}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Info grid */}
        <div className="grid sm:grid-cols-2 gap-4">
          <InfoRow icon={MapPin} label="Current Location" value={tracking.current_location ?? 'Not updated yet'} />
          <InfoRow icon={Clock} label="Last Updated" value={new Date(tracking.updated_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} />
          <InfoRow icon={Truck} label="Transport ID" value={`#${tracking.transport_id.slice(0, 8)}`} />
          <InfoRow icon={Package} label="Booking ID" value={`#${tracking.booking_id.slice(0, 8)}`} />
        </div>

        {tracking.notes && (
          <div className="mt-4 p-3 rounded-xl bg-amber-50 border border-amber-200">
            <div className="text-xs font-semibold text-amber-700 mb-1">Driver Notes</div>
            <div className="text-sm text-neutral-600">{tracking.notes}</div>
          </div>
        )}

        {/* Provider update controls */}
        {isProvider && (
          <div className="mt-6 pt-6 border-t border-neutral-100">
            <h4 className="text-sm font-bold text-neutral-900 mb-3">Update Status</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['pending', 'picked_up', 'in_transit', 'delivered'] as const).map(status => {
                const cfg = STATUS_CONFIG[status];
                const Icon = cfg.icon;
                return (
                  <button
                    key={status}
                    onClick={async () => {
                      await supabase.from('transport_tracking').update({
                        status,
                        updated_at: new Date().toISOString(),
                      }).eq('id', tracking.id);
                      onUpdate();
                    }}
                    disabled={tracking.status === status}
                    className={`p-3 rounded-xl border-2 text-sm font-semibold transition-all ${
                      tracking.status === status
                        ? 'border-green-500 bg-green-50 text-green-700 cursor-default'
                        : 'border-neutral-200 hover:border-green-300 text-neutral-600'
                    }`}
                  >
                    <Icon className="w-4 h-4 mx-auto mb-1" />
                    {cfg.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: typeof MapPin; label: string; value: string }) {
  return (
    <div className="p-3 rounded-xl bg-neutral-50">
      <div className="flex items-center gap-2 text-xs text-neutral-500 mb-1">
        <Icon className="w-3.5 h-3.5" /> {label}
      </div>
      <div className="text-sm font-semibold text-neutral-900">{value}</div>
    </div>
  );
}

function UpdateTrackingModal({ onClose }: { onClose: () => void }) {
  const { session } = useAuth();
  const [bookingId, setBookingId] = useState('');
  const [transportId, setTransportId] = useState('');
  const [status, setStatus] = useState<TransportTracking['status']>('pending');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = await supabase.from('transport_tracking').insert({
      booking_id: bookingId,
      transport_id: transportId,
      provider_id: session!.user.id,
      status,
      current_location: location || null,
      notes: notes || null,
    });

    if (error) { setError(error.message); setLoading(false); }
    else { onClose(); }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900">Add Tracking Record</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Booking ID</label>
              <input type="text" required value={bookingId} onChange={e => setBookingId(e.target.value)} placeholder="Booking UUID" className="input-field" />
            </div>
            <div>
              <label className="label">Transport ID</label>
              <input type="text" required value={transportId} onChange={e => setTransportId(e.target.value)} placeholder="Transport UUID" className="input-field" />
            </div>
          </div>
          <div>
            <label className="label">Status</label>
            <select value={status} onChange={e => setStatus(e.target.value as any)} className="input-field">
              <option value="pending">Pending Pickup</option>
              <option value="picked_up">Picked Up</option>
              <option value="in_transit">In Transit</option>
              <option value="delivered">Delivered</option>
            </select>
          </div>
          <div>
            <label className="label">Current Location</label>
            <input type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="e.g. NH 48, near Pune" className="input-field" />
          </div>
          <div>
            <label className="label">Notes (optional)</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} placeholder="Any delivery notes..." className="input-field resize-none" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 rounded-xl font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">{loading ? 'Adding...' : 'Add Tracking'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
