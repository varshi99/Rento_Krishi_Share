import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import type { UserRole } from '../lib/supabase';
import { Logo } from '../components/Logo';
import {
  Mail, Lock, User, Phone, MapPin, Eye, EyeOff, ArrowLeft, AlertCircle,
  Sprout, Tractor, Users, Truck, Shield
} from 'lucide-react';

const ROLES: { value: UserRole; label: string; icon: typeof Sprout; desc: string }[] = [
  { value: 'farmer', label: 'Farmer', icon: Sprout, desc: 'Rent equipment & hire workers' },
  { value: 'equipment_owner', label: 'Equipment Owner', icon: Tractor, desc: 'List & rent out your machinery' },
  { value: 'worker', label: 'Worker', icon: Users, desc: 'Find farm jobs near you' },
  { value: 'transport_provider', label: 'Transport Provider', icon: Truck, desc: 'Offer transport services' },
];

export function RegisterPage() {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [role, setRole] = useState<UserRole>('farmer');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    const { error } = await signUp(email, password, fullName, role, phone, location);
    if (error) {
      setError(error);
      setLoading(false);
    } else {
      navigate('/dashboard');
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-green-50 via-white to-amber-50">
      <div className="px-6 pt-8">
        <Link to="/" className="inline-flex items-center gap-2 text-sm font-semibold text-neutral-600 hover:text-green-700 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-2xl">
          <div className="text-center mb-8">
            <Link to="/"><Logo size="lg" /></Link>
            <h1 className="mt-6 text-2xl font-extrabold text-neutral-900">Create Your Account</h1>
            <p className="mt-2 text-sm text-neutral-500">Join India's agriculture sharing platform — it's free</p>
          </div>

          <div className="card p-8">
            {error && (
              <div className="mb-4 flex items-start gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Role Selection */}
              <div>
                <label className="label">I am a...</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {ROLES.map((r) => {
                    const Icon = r.icon;
                    const selected = role === r.value;
                    return (
                      <button
                        key={r.value}
                        type="button"
                        onClick={() => setRole(r.value)}
                        className={`p-4 rounded-xl border-2 text-center transition-all duration-150 ${
                          selected
                            ? 'border-green-600 bg-green-50 shadow-sm'
                            : 'border-neutral-200 hover:border-green-300 hover:bg-green-50/50'
                        }`}
                      >
                        <Icon className={`w-6 h-6 mx-auto mb-2 ${selected ? 'text-green-700' : 'text-neutral-400'}`} />
                        <div className={`text-sm font-semibold ${selected ? 'text-green-800' : 'text-neutral-700'}`}>{r.label}</div>
                      </button>
                    );
                  })}
                </div>
                <p className="mt-2 text-xs text-neutral-500">
                  {ROLES.find(r => r.value === role)?.desc}
                </p>
              </div>

              <div>
                <label className="label">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                  <input type="text" required value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Your full name" className="input-field pl-10" />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="label">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                    <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="input-field pl-10" />
                  </div>
                </div>
                <div>
                  <label className="label">Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                    <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 98765 43210" className="input-field pl-10" />
                  </div>
                </div>
              </div>

              <div>
                <label className="label">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                  <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, State" className="input-field pl-10" />
                </div>
              </div>

              <div>
                <label className="label">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                  <input type={showPassword ? 'text' : 'password'} required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Min. 6 characters" className="input-field pl-10 pr-10" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600">
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <label className="flex items-start gap-2 text-sm text-neutral-600">
                <input type="checkbox" required className="mt-0.5 rounded border-neutral-300 text-green-600 focus:ring-green-500" />
                <span>I agree to the <Link to="/terms" className="font-semibold text-green-700 hover:text-green-800">Terms of Service</Link> and <Link to="/privacy" className="font-semibold text-green-700 hover:text-green-800">Privacy Policy</Link></span>
              </label>

              <button type="submit" disabled={loading} className="btn-primary w-full justify-center disabled:opacity-60 disabled:cursor-not-allowed">
                {loading ? 'Creating account...' : 'Create Free Account'}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-neutral-500">
              Already have an account?{' '}
              <Link to="/login" className="font-semibold text-green-700 hover:text-green-800">Sign in</Link>
            </p>
          </div>

          <div className="mt-6 flex items-center justify-center gap-2 text-sm text-neutral-400">
            <Shield className="w-4 h-4" />
            <span>Your data is secure and encrypted</span>
          </div>
        </div>
      </div>
    </div>
  );
}
