import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { TrendingUp, Calendar, Wallet, Users, Tractor, Truck,
  Star, ArrowUpRight, ArrowDownRight, Activity, BarChart3, PieChart
} from 'lucide-react';

export function AnalyticsPage() {
  const { session } = useAuth();
  const [loading, setLoading] = useState(true);
  const [bookingStats, setBookingStats] = useState({ total: 0, pending: 0, confirmed: 0, completed: 0, cancelled: 0 });
  const [monthlyData, setMonthlyData] = useState<{ month: string; bookings: number; revenue: number }[]>([]);
  const [categoryData, setCategoryData] = useState<{ type: string; count: number; color: string }[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  useEffect(() => {
    async function loadAnalytics() {
      if (!session?.user?.id) return;
      const userId = session.user.id;

      const { data: bookings } = await supabase
        .from('bookings')
        .select('*')
        .eq('booker_id', userId)
        .order('created_at', { ascending: false });

      if (bookings) {
        setBookingStats({
          total: bookings.length,
          pending: bookings.filter(b => b.status === 'pending').length,
          confirmed: bookings.filter(b => b.status === 'confirmed').length,
          completed: bookings.filter(b => b.status === 'completed').length,
          cancelled: bookings.filter(b => b.status === 'cancelled').length,
        });

        // Monthly breakdown (last 6 months)
        const now = new Date();
        const months: { month: string; bookings: number; revenue: number }[] = [];
        for (let i = 5; i >= 0; i--) {
          const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
          const monthName = d.toLocaleDateString('en', { month: 'short' });
          const monthBookings = bookings.filter(b => {
            const bd = new Date(b.created_at);
            return bd.getMonth() === d.getMonth() && bd.getFullYear() === d.getFullYear();
          });
          months.push({
            month: monthName,
            bookings: monthBookings.length,
            revenue: monthBookings.reduce((s, b) => s + (b.total_cost || 0), 0),
          });
        }
        setMonthlyData(months);

        // Category breakdown
        const types = ['equipment', 'worker', 'transport'];
        const colors = { equipment: '#2d8a3e', worker: '#d4960a', transport: '#2d72d2' };
        setCategoryData(types.map(t => ({
          type: t,
          count: bookings.filter(b => b.listing_type === t).length,
          color: (colors as any)[t],
        })));

        setRecentActivity(bookings.slice(0, 5));
      }

      setLoading(false);
    }
    loadAnalytics();
  }, [session?.user?.id]);

  if (loading) {
    return <div className="text-center py-12 text-neutral-400">Loading analytics...</div>;
  }

  const maxBookings = Math.max(...monthlyData.map(m => m.bookings), 1);
  const maxRevenue = Math.max(...monthlyData.map(m => m.revenue), 1);
  const totalRevenue = monthlyData.reduce((s, m) => s + m.revenue, 0);
  const totalBookings = bookingStats.total;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-extrabold text-neutral-900 flex items-center gap-2">
          <BarChart3 className="w-7 h-7 text-green-700" /> Analytics Dashboard
        </h2>
        <p className="text-sm text-neutral-500 mt-1">Insights into your farming activity and spending patterns</p>
      </div>

      {/* Key metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard icon={Calendar} label="Total Bookings" value={totalBookings} trend={+12} color="green" />
        <MetricCard icon={Wallet} label="Total Revenue" value={`₹${totalRevenue.toLocaleString('en-IN')}`} trend={+8} color="amber" />
        <MetricCard icon={Activity} label="Completion Rate" value={`${totalBookings > 0 ? Math.round((bookingStats.completed / totalBookings) * 100) : 0}%`} trend={+5} color="blue" />
        <MetricCard icon={Star} label="Avg Rating" value="4.3" trend={+0.2} color="green" />
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Bar chart - monthly bookings */}
        <div className="lg:col-span-2 card p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-neutral-900">Booking & Revenue Trends</h3>
            <span className="text-xs text-neutral-400">Last 6 months</span>
          </div>
          <div className="flex items-end justify-between gap-2 sm:gap-4 h-48">
            {monthlyData.map((m, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full flex items-end justify-center gap-1 h-40">
                  {/* Bookings bar */}
                  <div className="flex-1 max-w-[20px] bg-green-200 rounded-t-md relative group cursor-pointer transition-all hover:bg-green-300"
                    style={{ height: `${(m.bookings / maxBookings) * 100}%`, minHeight: m.bookings > 0 ? '8px' : '0' }}
                  >
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-bold text-neutral-700 opacity-0 group-hover:opacity-100 transition-opacity">
                      {m.bookings}
                    </div>
                  </div>
                  {/* Revenue bar */}
                  <div className="flex-1 max-w-[20px] bg-amber-300 rounded-t-md relative group cursor-pointer transition-all hover:bg-amber-400"
                    style={{ height: `${(m.revenue / maxRevenue) * 100}%`, minHeight: m.revenue > 0 ? '8px' : '0' }}
                  >
                    <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-bold text-neutral-700 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      ₹{m.revenue}
                    </div>
                  </div>
                </div>
                <span className="text-xs text-neutral-500 font-medium">{m.month}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-6 mt-4 pt-4 border-t border-neutral-100">
            <div className="flex items-center gap-2 text-sm">
              <div className="w-3 h-3 rounded bg-green-300" />
              <span className="text-neutral-600">Bookings</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <div className="w-3 h-3 rounded bg-amber-400" />
              <span className="text-neutral-600">Revenue (₹)</span>
            </div>
          </div>
        </div>

        {/* Pie chart - category breakdown */}
        <div className="card p-6">
          <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2"><PieChart className="w-5 h-5 text-green-700" /> Booking Categories</h3>
          <div className="flex flex-col items-center">
            {/* SVG Donut chart */}
            <div className="relative">
              <svg width="160" height="160" viewBox="0 0 160 160">
                {renderDonutChart(categoryData)}
                <text x="80" y="75" textAnchor="middle" className="fill-neutral-900 font-extrabold" style={{ fontSize: '24px' }}>{totalBookings}</text>
                <text x="80" y="92" textAnchor="middle" className="fill-neutral-400" style={{ fontSize: '11px' }}>Total</text>
              </svg>
            </div>
            {/* Legend */}
            <div className="mt-4 w-full space-y-2">
              {categoryData.map((c) => (
                <div key={c.type} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: c.color }} />
                    <span className="text-neutral-600 capitalize">{c.type}</span>
                  </div>
                  <span className="font-bold text-neutral-900">{c.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Status breakdown + Recent activity */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Status breakdown */}
        <div className="card p-6">
          <h3 className="text-lg font-bold text-neutral-900 mb-4">Booking Status Breakdown</h3>
          <div className="space-y-3">
            <StatusBar label="Completed" count={bookingStats.completed} total={totalBookings} color="bg-green-500" />
            <StatusBar label="Confirmed" count={bookingStats.confirmed} total={totalBookings} color="bg-blue-500" />
            <StatusBar label="Pending" count={bookingStats.pending} total={totalBookings} color="bg-amber-500" />
            <StatusBar label="Cancelled" count={bookingStats.cancelled} total={totalBookings} color="bg-red-400" />
          </div>
        </div>

        {/* Recent activity */}
        <div className="card p-6">
          <h3 className="text-lg font-bold text-neutral-900 mb-4">Recent Activity</h3>
          {recentActivity.length === 0 ? (
            <div className="text-center py-8 text-sm text-neutral-400">No recent activity</div>
          ) : (
            <div className="space-y-3">
              {recentActivity.map((b, i) => (
                <div key={i} className="flex items-center gap-3 p-2 rounded-lg hover:bg-neutral-50">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    b.listing_type === 'equipment' ? 'bg-green-100 text-green-700' :
                    b.listing_type === 'worker' ? 'bg-amber-100 text-amber-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>
                    {b.listing_type === 'equipment' ? <Tractor className="w-4 h-4" /> :
                     b.listing_type === 'worker' ? <Users className="w-4 h-4" /> :
                     <Truck className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-neutral-900 capitalize">{b.listing_type} booking</div>
                    <div className="text-xs text-neutral-400">{new Date(b.created_at).toLocaleDateString('en-IN')}</div>
                  </div>
                  <div className="text-sm font-bold text-neutral-900">₹{b.total_cost}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Insights */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2"><TrendingUp className="w-5 h-5 text-green-700" /> Smart Insights</h3>
        <div className="grid sm:grid-cols-3 gap-4">
          <InsightCard
            icon={TrendingUp}
            title="Peak Booking Month"
            value={monthlyData.sort((a, b) => b.bookings - a.bookings)[0]?.month ?? '-'}
            desc="Most active month for bookings"
            color="bg-green-100 text-green-700"
          />
          <InsightCard
            icon={Wallet}
            title="Avg Booking Value"
            value={`₹${totalBookings > 0 ? Math.round(totalRevenue / totalBookings) : 0}`}
            desc="Average value per booking"
            color="bg-amber-100 text-amber-700"
          />
          <InsightCard
            icon={Activity}
            title="Most Booked Type"
            value={categoryData.sort((a, b) => b.count - a.count)[0]?.type ?? '-'}
            desc="Your most used service"
            color="bg-blue-100 text-blue-700"
          />
        </div>
      </div>
    </div>
  );
}

function MetricCard({ icon: Icon, label, value, trend, color }: { icon: typeof Calendar; label: string; value: string | number; trend: number; color: string }) {
  const colors: Record<string, string> = {
    green: 'bg-green-100 text-green-700',
    amber: 'bg-amber-100 text-amber-700',
    blue: 'bg-blue-100 text-blue-700',
  };
  const isPositive = trend >= 0;
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colors[color]}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className={`flex items-center gap-0.5 text-xs font-bold ${isPositive ? 'text-green-600' : 'text-red-500'}`}>
          {isPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
          {Math.abs(trend)}%
        </div>
      </div>
      <div className="text-2xl font-extrabold text-neutral-900">{value}</div>
      <div className="text-sm text-neutral-500 mt-0.5">{label}</div>
    </div>
  );
}

function StatusBar({ label, count, total, color }: { label: string; count: number; total: number; color: string }) {
  const pct = total > 0 ? (count / total) * 100 : 0;
  return (
    <div>
      <div className="flex items-center justify-between text-sm mb-1">
        <span className="text-neutral-600">{label}</span>
        <span className="font-bold text-neutral-900">{count} ({Math.round(pct)}%)</span>
      </div>
      <div className="h-2 rounded-full bg-neutral-100 overflow-hidden">
        <div className={`h-full rounded-full ${color} transition-all duration-500`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function InsightCard({ icon: Icon, title, value, desc, color }: { icon: typeof TrendingUp; title: string; value: string; desc: string; color: string }) {
  return (
    <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-100">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${color}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="text-xs text-neutral-500">{title}</div>
      <div className="text-lg font-bold text-neutral-900 capitalize mt-0.5">{value}</div>
      <div className="text-xs text-neutral-400 mt-0.5">{desc}</div>
    </div>
  );
}

function renderDonutChart(data: { type: string; count: number; color: string }[]) {
  const total = data.reduce((s, d) => s + d.count, 0);
  if (total === 0) return null;

  let cumulativeAngle = -90;
  const radius = 60;
  const cx = 80, cy = 80;
  const segments: any[] = [];

  data.forEach((d, i) => {
    if (d.count === 0) return;
    const angle = (d.count / total) * 360;
    const startAngle = cumulativeAngle;
    const endAngle = cumulativeAngle + angle;

    const startRad = (startAngle * Math.PI) / 180;
    const endRad = (endAngle * Math.PI) / 180;

    const x1 = cx + radius * Math.cos(startRad);
    const y1 = cy + radius * Math.sin(startRad);
    const x2 = cx + radius * Math.cos(endRad);
    const y2 = cy + radius * Math.sin(endRad);

    const largeArc = angle > 180 ? 1 : 0;

    segments.push(
      <path
        key={i}
        d={`M ${cx} ${cy} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`}
        fill={d.color}
        opacity={0.85}
      />
    );

    cumulativeAngle = endAngle;
  });

  // Inner circle for donut effect
  segments.push(<circle key="inner" cx={cx} cy={cy} r={36} fill="white" />);

  return <>{segments}</>;
}
