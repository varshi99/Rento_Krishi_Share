import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import {
  Tractor, Users, Truck, Calendar, Wallet, Star, TrendingUp,
  Clock, CheckCircle, AlertCircle, ArrowRight, CloudSun
} from 'lucide-react';

const ROLE_LABELS: Record<string, string> = {
  farmer: 'Farmer',
  equipment_owner: 'Equipment Owner',
  worker: 'Worker',
  transport_provider: 'Transport Provider',
  admin: 'Admin',
};

export function DashboardPage() {
  const { profile, session } = useAuth();
  const [stats, setStats] = useState({ bookings: 0, listings: 0, reviews: 0, earnings: 0 });
  const [recentBookings, setRecentBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDashboard() {
      if (!session?.user?.id) return;
      const userId = session.user.id;

      const [bookingsRes, listingsRes, reviewsRes] = await Promise.all([
        supabase.from('bookings').select('*').eq('booker_id', userId).order('created_at', { ascending: false }).limit(5),
        profile?.role === 'equipment_owner'
          ? supabase.from('equipment').select('*').eq('owner_id', userId)
          : profile?.role === 'worker'
          ? supabase.from('workers').select('*').eq('user_id', userId)
          : profile?.role === 'transport_provider'
          ? supabase.from('transport').select('*').eq('provider_id', userId)
          : Promise.resolve({ data: [], error: null }),
        supabase.from('reviews').select('*').eq('reviewer_id', userId),
      ]);

      setStats({
        bookings: bookingsRes.data?.length ?? 0,
        listings: (listingsRes as any).data?.length ?? 0,
        reviews: reviewsRes.data?.length ?? 0,
        earnings: 0,
      });
      setRecentBookings(bookingsRes.data ?? []);
      setLoading(false);
    }
    loadDashboard();
  }, [session, profile]);

  const role = profile?.role ?? 'farmer';
  const roleLabel = ROLE_LABELS[role];

  const quickActions = getQuickActions(role);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome banner */}
      <div className="rounded-2xl bg-gradient-to-r from-green-700 to-green-800 p-6 sm:p-8 text-white">
        <h2 className="text-2xl font-extrabold">Welcome back, {profile?.full_name?.split(' ')[0] ?? 'Farmer'}!</h2>
        <p className="mt-1 text-green-100">Here's what's happening with your {roleLabel.toLowerCase()} account today.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Calendar} label="Total Bookings" value={stats.bookings} color="green" />
        <StatCard icon={Tractor} label={role === 'equipment_owner' ? 'My Equipment' : role === 'worker' ? 'My Profile' : role === 'transport_provider' ? 'My Vehicles' : 'Listings'} value={stats.listings} color="amber" />
        <StatCard icon={Star} label="Reviews Given" value={stats.reviews} color="blue" />
        <StatCard icon={Wallet} label="Total Spent" value={`₹${stats.earnings}`} color="green" />
      </div>

      {/* Quick actions */}
      <div>
        <h3 className="text-lg font-bold text-neutral-900 mb-4">Quick Actions</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link key={action.label} to={action.link} className="card p-5 group hover:-translate-y-0.5 transition-all duration-200">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${action.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="font-semibold text-neutral-900 text-sm">{action.label}</div>
                <div className="flex items-center gap-1 mt-2 text-xs font-semibold text-green-700 group-hover:gap-2 transition-all">
                  Get started <ArrowRight className="w-3 h-3" />
                </div>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Recent bookings + Weather */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent bookings */}
        <div className="lg:col-span-2 card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-neutral-900">Recent Bookings</h3>
            <Link to="/dashboard/bookings" className="text-sm font-semibold text-green-700 hover:text-green-800 flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="py-8 text-center text-neutral-400 text-sm">Loading bookings...</div>
          ) : recentBookings.length === 0 ? (
            <div className="py-8 text-center">
              <Calendar className="w-12 h-12 mx-auto text-neutral-300 mb-3" />
              <p className="text-neutral-500 text-sm">No bookings yet. Start by browsing equipment!</p>
              <Link to="/dashboard/equipment" className="btn-secondary text-sm mt-4 inline-flex">Browse Equipment</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {recentBookings.map((booking) => (
                <div key={booking.id} className="flex items-center gap-4 p-3 rounded-xl bg-neutral-50 hover:bg-neutral-100 transition-colors">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusColor(booking.status)}`}>
                    {getStatusIcon(booking.status)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm text-neutral-900 capitalize">{booking.listing_type} booking</div>
                    <div className="text-xs text-neutral-500">{booking.start_date} → {booking.end_date}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-sm text-neutral-900">₹{booking.total_cost}</div>
                    <div className="text-xs capitalize text-neutral-500">{booking.status}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Weather widget */}
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <CloudSun className="w-5 h-5 text-amber-500" />
            <h3 className="text-lg font-bold text-neutral-900">Weather Today</h3>
          </div>
          <div className="text-center py-4">
            <div className="text-5xl font-extrabold text-neutral-900">28°C</div>
            <div className="text-sm text-neutral-500 mt-1">Sunny, Light Breeze</div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div className="p-3 rounded-xl bg-blue-50">
                <div className="text-xs text-neutral-500">Humidity</div>
                <div className="font-bold text-blue-700">65%</div>
              </div>
              <div className="p-3 rounded-xl bg-green-50">
                <div className="text-xs text-neutral-500">Wind</div>
                <div className="font-bold text-green-700">12 km/h</div>
              </div>
            </div>
            <Link to="/dashboard/weather" className="btn-secondary text-sm mt-4 w-full justify-center">
              View Forecast
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: typeof Tractor; label: string; value: string | number; color: string }) {
  const colors: Record<string, string> = {
    green: 'bg-green-100 text-green-700',
    amber: 'bg-amber-100 text-amber-700',
    blue: 'bg-blue-100 text-blue-700',
  };
  return (
    <div className="card p-5">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${colors[color]}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="text-2xl font-extrabold text-neutral-900">{value}</div>
      <div className="text-sm text-neutral-500 mt-0.5">{label}</div>
    </div>
  );
}

function getStatusColor(status: string) {
  switch (status) {
    case 'confirmed': return 'bg-green-100 text-green-700';
    case 'completed': return 'bg-blue-100 text-blue-700';
    case 'pending': return 'bg-amber-100 text-amber-700';
    case 'cancelled': return 'bg-red-100 text-red-700';
    default: return 'bg-neutral-100 text-neutral-500';
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case 'confirmed': return <CheckCircle className="w-5 h-5" />;
    case 'completed': return <CheckCircle className="w-5 h-5" />;
    case 'pending': return <Clock className="w-5 h-5" />;
    case 'cancelled': return <AlertCircle className="w-5 h-5" />;
    default: return <Clock className="w-5 h-5" />;
  }
}

function getQuickActions(role: string) {
  const actions = {
    farmer: [
      { icon: Tractor, label: 'Rent Equipment', link: '/dashboard/equipment', color: 'bg-green-100 text-green-700' },
      { icon: Users, label: 'Hire Workers', link: '/dashboard/workers', color: 'bg-amber-100 text-amber-700' },
      { icon: Truck, label: 'Book Transport', link: '/dashboard/transport', color: 'bg-blue-100 text-blue-700' },
      { icon: CloudSun, label: 'Check Weather', link: '/dashboard/weather', color: 'bg-green-100 text-green-700' },
    ],
    equipment_owner: [
      { icon: Tractor, label: 'Add Equipment', link: '/dashboard/equipment', color: 'bg-green-100 text-green-700' },
      { icon: Calendar, label: 'View Bookings', link: '/dashboard/bookings', color: 'bg-amber-100 text-amber-700' },
      { icon: Wallet, label: 'Earnings', link: '/dashboard/payments', color: 'bg-blue-100 text-blue-700' },
      { icon: Star, label: 'Reviews', link: '/dashboard/reviews', color: 'bg-green-100 text-green-700' },
    ],
    worker: [
      { icon: Calendar, label: 'Available Jobs', link: '/dashboard/workers', color: 'bg-green-100 text-green-700' },
      { icon: Wallet, label: 'My Earnings', link: '/dashboard/payments', color: 'bg-amber-100 text-amber-700' },
      { icon: Star, label: 'My Ratings', link: '/dashboard/reviews', color: 'bg-blue-100 text-blue-700' },
      { icon: Users, label: 'My Profile', link: '/dashboard/profile', color: 'bg-green-100 text-green-700' },
    ],
    transport_provider: [
      { icon: Truck, label: 'Add Vehicle', link: '/dashboard/transport', color: 'bg-green-100 text-green-700' },
      { icon: Calendar, label: 'Deliveries', link: '/dashboard/bookings', color: 'bg-amber-100 text-amber-700' },
      { icon: Wallet, label: 'Earnings', link: '/dashboard/payments', color: 'bg-blue-100 text-blue-700' },
      { icon: Star, label: 'Reviews', link: '/dashboard/reviews', color: 'bg-green-100 text-green-700' },
    ],
    admin: [
      { icon: Users, label: 'User Management', link: '/dashboard/profile', color: 'bg-green-100 text-green-700' },
      { icon: Tractor, label: 'Equipment', link: '/dashboard/equipment', color: 'bg-amber-100 text-amber-700' },
      { icon: TrendingUp, label: 'Analytics', link: '/dashboard', color: 'bg-blue-100 text-blue-700' },
      { icon: Star, label: 'Reports', link: '/dashboard/reviews', color: 'bg-green-100 text-green-700' },
    ],
  };
  return actions[role as keyof typeof actions] ?? actions.farmer;
}
