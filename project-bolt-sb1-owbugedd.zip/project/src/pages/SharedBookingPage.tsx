import { useEffect, useState } from 'react';
import { supabase, type SharedBooking } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Users, Plus, MapPin, Calendar, Share2, X, TrendingDown } from 'lucide-react';

export function SharedBookingPage() {
  const { session } = useAuth();
  const [sharedBookings, setSharedBookings] = useState<(SharedBooking & { participants?: any[] })[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  useEffect(() => { loadSharedBookings(); }, []);

  async function loadSharedBookings() {
    const { data, error } = await supabase
      .from('shared_bookings')
      .select('*, shared_booking_participants(*)')
      .order('created_at', { ascending: false });

    if (error) console.error(error);
    setSharedBookings(data as any ?? []);
    setLoading(false);
  }

  async function joinBooking(id: string, currentParticipants: number, maxParticipants: number) {
    if (!session?.user?.id) return;
    if (currentParticipants >= maxParticipants) return;

    const { error } = await supabase.from('shared_booking_participants').insert({
      shared_booking_id: id,
      user_id: session.user.id,
    });

    if (error) {
      console.error(error);
      return;
    }

    await supabase.from('shared_bookings').update({
      current_participants: currentParticipants + 1,
      status: currentParticipants + 1 >= maxParticipants ? 'full' : 'open',
    }).eq('id', id);

    loadSharedBookings();
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Shared Bookings</h2>
          <p className="text-sm text-neutral-500 mt-1">Split costs with nearby farmers through group bookings</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn-primary">
          <Plus className="w-5 h-5" /> Create Shared Booking
        </button>
      </div>

      {/* Benefits banner */}
      <div className="rounded-2xl bg-gradient-to-r from-green-700 to-green-800 p-6 text-white">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center">
            <TrendingDown className="w-7 h-7 text-green-300" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Save up to 60% with shared bookings</h3>
            <p className="text-green-100 text-sm mt-1">Join forces with nearby farmers to split equipment, worker, and transport costs.</p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading shared bookings...</div>
      ) : sharedBookings.length === 0 ? (
        <div className="card p-12 text-center">
          <Users className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No shared bookings yet</h3>
          <p className="text-sm text-neutral-500 mt-1">Create one to start saving with nearby farmers.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {sharedBookings.map((sb) => {
            const spotsLeft = sb.max_participants - sb.current_participants;
            const isFull = spotsLeft <= 0;
            const hasJoined = sb.participants?.some((p: any) => p.user_id === session?.user?.id);
            return (
              <div key={sb.id} className="card p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                      <Share2 className="w-5 h-5 text-green-700" />
                    </div>
                    <div>
                      <div className="font-bold text-neutral-900 capitalize">{sb.listing_type} Sharing</div>
                      <div className="text-xs text-neutral-500">{sb.location ?? 'No location'}</div>
                    </div>
                  </div>
                  <span className={`badge ${isFull ? 'bg-neutral-100 text-neutral-500' : 'bg-green-100 text-green-700'}`}>
                    {isFull ? 'Full' : `${spotsLeft} spots left`}
                  </span>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-neutral-600">
                    <Calendar className="w-4 h-4 text-neutral-400" />
                    {sb.start_date} → {sb.end_date}
                  </div>
                  <div className="flex items-center gap-2 text-neutral-600">
                    <Users className="w-4 h-4 text-neutral-400" />
                    {sb.current_participants}/{sb.max_participants} farmers joined
                  </div>
                  {sb.location && (
                    <div className="flex items-center gap-2 text-neutral-600">
                      <MapPin className="w-4 h-4 text-neutral-400" /> {sb.location}
                    </div>
                  )}
                </div>

                {sb.notes && <p className="text-sm text-neutral-500 mt-3 line-clamp-2">{sb.notes}</p>}

                {/* Cost split */}
                <div className="mt-4 p-3 rounded-xl bg-green-50 border border-green-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs text-neutral-500">Total Cost</div>
                      <div className="font-bold text-neutral-900">₹{sb.total_cost}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-neutral-500">Per Person</div>
                      <div className="font-bold text-green-700">₹{sb.per_person_cost}</div>
                    </div>
                  </div>
                </div>

                {/* Participants avatars */}
                <div className="flex items-center gap-2 mt-3">
                  <div className="flex -space-x-2">
                    {Array.from({ length: sb.current_participants }).map((_, i) => (
                      <div key={i} className="w-7 h-7 rounded-full bg-green-200 border-2 border-white flex items-center justify-center text-xs font-bold text-green-800">
                        F{i + 1}
                      </div>
                    ))}
                  </div>
                  <span className="text-xs text-neutral-400">{sb.current_participants} joined</span>
                </div>

                <button
                  onClick={() => !hasJoined && !isFull && joinBooking(sb.id, sb.current_participants, sb.max_participants)}
                  disabled={isFull || hasJoined}
                  className={`w-full mt-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                    hasJoined
                      ? 'bg-green-100 text-green-700 cursor-default'
                      : isFull
                      ? 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                      : 'bg-green-700 text-white hover:bg-green-800'
                  }`}
                >
                  {hasJoined ? 'Joined' : isFull ? 'Full' : 'Join & Save'}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {showCreate && <CreateSharedBookingModal onClose={() => { setShowCreate(false); loadSharedBookings(); }} />}
    </div>
  );
}

function CreateSharedBookingModal({ onClose }: { onClose: () => void }) {
  const { session } = useAuth();
  const [listingType, setListingType] = useState<'equipment' | 'worker' | 'transport'>('equipment');
  const [listingId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [totalCost, setTotalCost] = useState('');
  const [maxParticipants, setMaxParticipants] = useState('2');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const perPerson = maxParticipants && totalCost ? Math.ceil(parseFloat(totalCost) / parseInt(maxParticipants)) : 0;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { data, error } = await supabase.from('shared_bookings').insert({
      creator_id: session!.user.id,
      listing_type: listingType,
      listing_id: listingId || crypto.randomUUID(),
      start_date: startDate,
      end_date: endDate,
      total_cost: parseFloat(totalCost),
      per_person_cost: perPerson,
      max_participants: parseInt(maxParticipants),
      current_participants: 1,
      location,
      notes,
    }).select().single();

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    await supabase.from('shared_booking_participants').insert({
      shared_booking_id: data.id,
      user_id: session!.user.id,
    });

    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900">Create Shared Booking</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>}

          <div>
            <label className="label">What are you sharing?</label>
            <div className="grid grid-cols-3 gap-2">
              {(['equipment', 'worker', 'transport'] as const).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setListingType(t)}
                  className={`p-3 rounded-xl border-2 text-sm font-semibold capitalize transition-all ${listingType === t ? 'border-green-600 bg-green-50 text-green-800' : 'border-neutral-200 text-neutral-600 hover:border-green-300'}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Start Date</label>
              <input type="date" required value={startDate} onChange={e => setStartDate(e.target.value)} className="input-field" />
            </div>
            <div>
              <label className="label">End Date</label>
              <input type="date" required value={endDate} onChange={e => setEndDate(e.target.value)} className="input-field" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Total Cost (₹)</label>
              <input type="number" required value={totalCost} onChange={e => setTotalCost(e.target.value)} placeholder="2400" className="input-field" />
            </div>
            <div>
              <label className="label">Max Participants</label>
              <input type="number" required min="2" max="10" value={maxParticipants} onChange={e => setMaxParticipants(e.target.value)} className="input-field" />
            </div>
          </div>

          <div>
            <label className="label">Location</label>
            <input type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="Village, District" className="input-field" />
          </div>

          <div>
            <label className="label">Notes (optional)</label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} placeholder="Share details about what you're booking..." className="input-field resize-none" />
          </div>

          {/* Cost preview */}
          {perPerson > 0 && (
            <div className="p-4 rounded-xl bg-green-50 border border-green-200">
              <div className="flex items-center justify-between">
                <div className="text-sm text-neutral-600">Each participant pays:</div>
                <div className="text-lg font-extrabold text-green-700">₹{perPerson}</div>
              </div>
              <div className="text-xs text-neutral-500 mt-1">You save ₹{parseFloat(totalCost) - perPerson} per person</div>
            </div>
          )}

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 rounded-xl font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">{loading ? 'Creating...' : 'Create & Share'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
