import { useEffect, useState } from 'react';
import { supabase, type Transport } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Truck, Plus, Search, MapPin, Star, X } from 'lucide-react';
import { CheckoutModal } from '../components/CheckoutModal';

const VEHICLE_TYPES = ['Mini Truck', 'Tractor Trailer', 'Pickup', 'Cargo Truck', 'Tempo', 'Bullock Cart', 'Other'];

export function TransportPage() {
  const { profile } = useAuth();
  const [transport, setTransport] = useState<(Transport & { profiles?: any })[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [checkoutItem, setCheckoutItem] = useState<(Transport & { profiles?: any }) | null>(null);

  useEffect(() => { loadTransport(); }, [search]);

  async function loadTransport() {
    let query = supabase.from('transport').select('*, profiles!transport_provider_id_fkey(full_name, location, phone)').order('created_at', { ascending: false });
    if (search) query = query.ilike('vehicle_type', `%${search}%`);
    const { data, error } = await query;
    if (error) console.error(error);
    setTransport(data ?? []);
    setLoading(false);
  }

  const isProvider = profile?.role === 'transport_provider' || profile?.role === 'admin';

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Transport Services</h2>
          <p className="text-sm text-neutral-500 mt-1">Book vehicles for pickup, delivery, and transport</p>
        </div>
        {isProvider && (
          <button onClick={() => setShowAdd(true)} className="btn-primary">
            <Plus className="w-5 h-5" /> Add Vehicle
          </button>
        )}
      </div>

      <div className="card p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
          <input type="text" placeholder="Search by vehicle type..." value={search} onChange={(e) => setSearch(e.target.value)} className="input-field pl-10 py-2.5" />
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading transport...</div>
      ) : transport.length === 0 ? (
        <div className="card p-12 text-center">
          <Truck className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No vehicles found</h3>
          <p className="text-sm text-neutral-500 mt-1">Try a different search or add your vehicle.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {transport.map((t) => (
            <div key={t.id} className="card overflow-hidden group">
              <div className="h-40 bg-gradient-to-br from-blue-100 to-green-100 flex items-center justify-center">
                <Truck className="w-16 h-16 text-blue-400" />
              </div>
              <div className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-neutral-900">{t.vehicle_type}</h3>
                    {t.vehicle_number && <span className="text-xs font-mono text-neutral-500">{t.vehicle_number}</span>}
                  </div>
                  <span className={`badge ${t.available ? 'bg-green-100 text-green-700' : 'bg-neutral-100 text-neutral-500'}`}>
                    {t.available ? 'Available' : 'Booked'}
                  </span>
                </div>
                {t.driver_name && <p className="text-sm text-neutral-500 mt-2">Driver: {t.driver_name}</p>}
                {t.capacity && <p className="text-sm text-neutral-500">Capacity: {t.capacity}</p>}
                {t.location && (
                  <div className="flex items-center gap-1 mt-2 text-sm text-neutral-500"><MapPin className="w-4 h-4" /> {t.location}</div>
                )}
                <div className="flex items-center justify-between mt-4">
                  <div>
                    <span className="text-lg font-extrabold text-green-700">₹{t.daily_rate}</span>
                    <span className="text-xs text-neutral-500">/day</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm">
                    <Star className="w-4 h-4 text-amber-400 fill-current" />
                    <span className="font-semibold text-neutral-700">4.3</span>
                  </div>
                </div>
                {profile?.role === 'farmer' && (
                  <button onClick={() => setCheckoutItem(t)} disabled={!t.available} className="btn-primary w-full justify-center mt-4 text-sm py-2.5 disabled:opacity-50">{t.available ? 'Book Transport' : 'Unavailable'}</button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {showAdd && <AddTransportModal onClose={() => { setShowAdd(false); loadTransport(); }} />}
      {checkoutItem && (
        <CheckoutModal
          item={{ name: checkoutItem.vehicle_type, type: 'transport', dailyRate: checkoutItem.daily_rate, days: 1, listingId: checkoutItem.id }}
          onClose={() => setCheckoutItem(null)}
          onSuccess={() => { setCheckoutItem(null); loadTransport(); }}
        />
      )}
    </div>
  );
}

function AddTransportModal({ onClose }: { onClose: () => void }) {
  const { session } = useAuth();
  const [vehicleType, setVehicleType] = useState(VEHICLE_TYPES[0]);
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [capacity, setCapacity] = useState('');
  const [driverName, setDriverName] = useState('');
  const [dailyRate, setDailyRate] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.from('transport').insert({
      provider_id: session!.user.id,
      vehicle_type: vehicleType,
      vehicle_number: vehicleNumber || null,
      capacity: capacity || null,
      driver_name: driverName || null,
      daily_rate: parseFloat(dailyRate),
      location,
    });
    if (error) { setError(error.message); setLoading(false); }
    else { onClose(); }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900">Add Vehicle</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Vehicle Type</label>
              <select value={vehicleType} onChange={(e) => setVehicleType(e.target.value)} className="input-field">
                {VEHICLE_TYPES.map(v => <option key={v} value={v}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Vehicle Number</label>
              <input type="text" value={vehicleNumber} onChange={(e) => setVehicleNumber(e.target.value)} placeholder="MH 12 AB 1234" className="input-field" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Capacity</label>
              <input type="text" value={capacity} onChange={(e) => setCapacity(e.target.value)} placeholder="2 tons" className="input-field" />
            </div>
            <div>
              <label className="label">Daily Rate (₹)</label>
              <input type="number" required value={dailyRate} onChange={(e) => setDailyRate(e.target.value)} placeholder="1500" className="input-field" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Driver Name</label>
              <input type="text" value={driverName} onChange={(e) => setDriverName(e.target.value)} placeholder="Driver name" className="input-field" />
            </div>
            <div>
              <label className="label">Location</label>
              <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, State" className="input-field" />
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 rounded-xl font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">{loading ? 'Adding...' : 'Add Vehicle'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
