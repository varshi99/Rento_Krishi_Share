import { useState } from 'react';
import { useNotifications } from '../hooks/useNotifications';
import { Bell, Check, Trash2, Clock } from 'lucide-react';

const TYPE_ICONS: Record<string, string> = {
  booking: '📅',
  payment: '💳',
  weather: '🌤️',
  transport: '🚚',
  system: '⚙️',
  review: '⭐',
  shared_booking: '👥',
};

const TYPE_COLORS: Record<string, string> = {
  booking: 'bg-green-100 text-green-700',
  payment: 'bg-amber-100 text-amber-700',
  weather: 'bg-blue-100 text-blue-700',
  transport: 'bg-blue-100 text-blue-700',
  system: 'bg-neutral-100 text-neutral-700',
  review: 'bg-amber-100 text-amber-700',
  shared_booking: 'bg-green-100 text-green-700',
};

function timeAgo(dateString: string): string {
  const diff = Date.now() - new Date(dateString).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export function NotificationsPage() {
  const { notifications, loading, markAsRead, markAllAsRead, deleteNotification } = useNotifications();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const filtered = filter === 'unread' ? notifications.filter(n => !n.is_read) : notifications;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Notifications</h2>
          <p className="text-sm text-neutral-500 mt-1">Stay updated on bookings, payments, and alerts</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 p-1 rounded-xl bg-neutral-100">
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${filter === 'all' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-500'}`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${filter === 'unread' ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-500'}`}
            >
              Unread
            </button>
          </div>
          {notifications.some(n => !n.is_read) && (
            <button onClick={markAllAsRead} className="btn-secondary text-sm py-2 px-3">
              <Check className="w-4 h-4" /> Mark all read
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading notifications...</div>
      ) : filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <Bell className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">
            {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
          </h3>
          <p className="text-sm text-neutral-500 mt-1">
            {filter === 'unread' ? 'You\'re all caught up!' : 'Notifications will appear here when you get updates.'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((n) => (
            <div
              key={n.id}
              className={`card p-4 flex items-start gap-4 group ${!n.is_read ? 'border-l-4 border-l-green-500' : ''}`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-lg ${TYPE_COLORS[n.type] ?? TYPE_COLORS.system}`}>
                {TYPE_ICONS[n.type] ?? '🔔'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold text-neutral-900">{n.title}</div>
                    <div className="text-sm text-neutral-500 mt-0.5">{n.message}</div>
                  </div>
                  {!n.is_read && <span className="badge bg-green-100 text-green-700 flex-shrink-0">New</span>}
                </div>
                <div className="flex items-center gap-3 mt-2">
                  <span className="text-xs text-neutral-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {timeAgo(n.created_at)}
                  </span>
                  <div className="flex items-center gap-1">
                    {!n.is_read && (
                      <button
                        onClick={() => markAsRead(n.id)}
                        className="text-xs font-semibold text-green-700 hover:text-green-800 flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" /> Mark read
                      </button>
                    )}
                    <button
                      onClick={() => deleteNotification(n.id)}
                      className="text-xs font-semibold text-neutral-400 hover:text-red-600 flex items-center gap-1 ml-2"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
