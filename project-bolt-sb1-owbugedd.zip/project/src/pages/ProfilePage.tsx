import { useState, type FormEvent } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { User, Mail, Phone, MapPin, Save, Shield } from 'lucide-react';

const ROLE_LABELS: Record<string, string> = {
  farmer: 'Farmer',
  equipment_owner: 'Equipment Owner',
  worker: 'Worker',
  transport_provider: 'Transport Provider',
  admin: 'Admin',
};

export function ProfilePage() {
  const { profile, session, refreshProfile } = useAuth();
  const [fullName, setFullName] = useState(profile?.full_name ?? '');
  const [phone, setPhone] = useState(profile?.phone ?? '');
  const [location, setLocation] = useState(profile?.location ?? '');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(false);

    const { error } = await supabase.from('profiles').update({
      full_name: fullName,
      phone,
      location,
      updated_at: new Date().toISOString(),
    }).eq('id', session!.user.id);

    if (error) {
      setError(error.message);
    } else {
      setSuccess(true);
      await refreshProfile();
    }
    setLoading(false);
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-extrabold text-neutral-900">My Profile</h2>
        <p className="text-sm text-neutral-500 mt-1">Manage your account information</p>
      </div>

      {/* Profile header */}
      <div className="card p-6">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-2xl bg-green-100 flex items-center justify-center text-2xl font-extrabold text-green-700">
            {profile?.full_name?.charAt(0).toUpperCase() ?? 'U'}
          </div>
          <div>
            <h3 className="text-xl font-bold text-neutral-900">{profile?.full_name ?? 'User'}</h3>
            <div className="flex items-center gap-2 mt-1">
              <span className="badge bg-green-100 text-green-700">{ROLE_LABELS[profile?.role ?? 'farmer']}</span>
              <span className="text-sm text-neutral-500">{session?.user?.email}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Edit form */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4">Edit Profile</h3>

        {success && (
          <div className="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-sm text-green-700 flex items-center gap-2">
            <Shield className="w-4 h-4" /> Profile updated successfully!
          </div>
        )}
        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="label">Full Name</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input type="text" required value={fullName} onChange={e => setFullName(e.target.value)} className="input-field pl-10" />
            </div>
          </div>
          <div>
            <label className="label">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
              <input type="email" value={session?.user?.email ?? ''} disabled className="input-field pl-10 bg-neutral-50 text-neutral-500" />
            </div>
            <p className="text-xs text-neutral-400 mt-1">Email cannot be changed</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+91 98765 43210" className="input-field pl-10" />
              </div>
            </div>
            <div>
              <label className="label">Location</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input type="text" value={location} onChange={e => setLocation(e.target.value)} placeholder="City, State" className="input-field pl-10" />
              </div>
            </div>
          </div>
          <button type="submit" disabled={loading} className="btn-primary disabled:opacity-60">
            <Save className="w-5 h-5" /> {loading ? 'Saving...' : 'Save Changes'}
          </button>
        </form>
      </div>
    </div>
  );
}
