import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase, type Payment } from '../lib/supabase';
import {
  Wallet, ArrowUpRight, ArrowDownRight, Download, CreditCard,
  IndianRupee, TrendingUp, Clock, CheckCircle, AlertCircle, Loader2, Calendar
} from 'lucide-react';

export function PaymentsPage() {
  const { session } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'completed' | 'pending' | 'failed'>('all');

  useEffect(() => {
    loadPayments();
  }, []);

  async function loadPayments() {
    if (!session?.user?.id) return;
    const { data, error } = await supabase
      .from('payments')
      .select('*')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false });
    if (error) console.error('Error loading payments:', error);
    setPayments(data ?? []);
    setLoading(false);
  }

  const filtered = filter === 'all' ? payments : payments.filter(p => p.status === filter);

  const totalSpent = payments.filter(p => p.status === 'completed').reduce((s, p) => s + Number(p.amount), 0);
  const pendingCount = payments.filter(p => p.status === 'pending').length;
  const completedCount = payments.filter(p => p.status === 'completed').length;
  const avgTransaction = completedCount > 0 ? Math.round(totalSpent / completedCount) : 0;

  function downloadReceipt(p: Payment) {
    const receipt = `
      KRISHISHARE - PAYMENT RECEIPT
      ================================
      Transaction ID: ${p.razorpay_payment_id ?? p.id}
      Order ID: ${p.razorpay_order_id ?? 'N/A'}
      Date: ${new Date(p.created_at).toLocaleString('en-IN')}
      Description: ${p.listing_name ?? 'Booking'} (${p.listing_type ?? 'N/A'})
      Payment Method: ${p.payment_method ?? 'N/A'}
      Amount: ₹${Number(p.amount).toLocaleString('en-IN')}
      Status: ${p.status.toUpperCase()}
      ================================
      Thank you for using KrishiShare!
    `.trim().replace(/^ {6}/gm, '');

    const blob = new Blob([receipt], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt_${p.id.slice(0, 8)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (loading) {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Payments</h2>
          <p className="text-sm text-neutral-500 mt-1">Your transaction history</p>
        </div>
        <div className="card p-12 text-center">
          <Loader2 className="w-8 h-8 mx-auto text-green-600 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-extrabold text-neutral-900">Payments</h2>
        <p className="text-sm text-neutral-500 mt-1">Your transaction history and payment methods</p>
      </div>

      {/* Summary cards */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5">
          <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center mb-3">
            <IndianRupee className="w-5 h-5 text-green-700" />
          </div>
          <div className="text-2xl font-extrabold text-neutral-900">₹{totalSpent.toLocaleString('en-IN')}</div>
          <div className="text-sm text-neutral-500">Total Spent</div>
        </div>
        <div className="card p-5">
          <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center mb-3">
            <Clock className="w-5 h-5 text-amber-600" />
          </div>
          <div className="text-2xl font-extrabold text-neutral-900">{pendingCount}</div>
          <div className="text-sm text-neutral-500">Pending</div>
        </div>
        <div className="card p-5">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center mb-3">
            <CheckCircle className="w-5 h-5 text-blue-600" />
          </div>
          <div className="text-2xl font-extrabold text-neutral-900">{completedCount}</div>
          <div className="text-sm text-neutral-500">Completed</div>
        </div>
        <div className="card p-5">
          <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center mb-3">
            <TrendingUp className="w-5 h-5 text-purple-600" />
          </div>
          <div className="text-2xl font-extrabold text-neutral-900">₹{avgTransaction.toLocaleString('en-IN')}</div>
          <div className="text-sm text-neutral-500">Avg Transaction</div>
        </div>
      </div>

      {/* Payment methods */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4">Payment Methods</h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl border-2 border-green-200 bg-green-50 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-700 flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-semibold text-neutral-900">UPI</div>
              <div className="text-xs text-neutral-500">Pay via any UPI app</div>
            </div>
          </div>
          <div className="p-4 rounded-xl border-2 border-neutral-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-neutral-700 flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-semibold text-neutral-900">Card</div>
              <div className="text-xs text-neutral-500">Credit / Debit Card</div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 mt-4 text-xs text-neutral-400">
          <Wallet className="w-4 h-4" /> Powered by Razorpay · Secure 256-bit encryption
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex flex-wrap gap-2">
        {(['all', 'completed', 'pending', 'failed'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold capitalize transition-colors ${filter === f ? 'bg-green-700 text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Transaction list */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4">Transactions</h3>
        {filtered.length === 0 ? (
          <div className="py-12 text-center">
            <Wallet className="w-12 h-12 mx-auto text-neutral-300 mb-3" />
            <p className="text-sm text-neutral-500">No transactions yet</p>
            <p className="text-xs text-neutral-400 mt-1">Book equipment, workers, or transport to see payments here</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((p) => (
              <div key={p.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-neutral-50 transition-colors">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${statusBg(p.status)}`}>
                  {statusIcon(p.status)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-neutral-900">{p.listing_name ?? 'Booking'}</div>
                  <div className="text-xs text-neutral-500 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(p.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                    {' · '}
                    <span className="capitalize">{p.listing_type ?? 'N/A'}</span>
                    {' · '}
                    <span className="capitalize">{p.payment_method ?? 'N/A'}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-sm text-neutral-900">₹{Number(p.amount).toLocaleString('en-IN')}</div>
                  <span className={`badge capitalize ${statusBadge(p.status)}`}>{p.status}</span>
                </div>
                {p.status === 'completed' && (
                  <button
                    onClick={() => downloadReceipt(p)}
                    className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100 hover:text-neutral-700"
                    title="Download receipt"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function statusBg(status: string) {
  switch (status) {
    case 'completed': return 'bg-green-100 text-green-700';
    case 'pending':   return 'bg-amber-100 text-amber-700';
    case 'failed':    return 'bg-red-100 text-red-700';
    case 'refunded':  return 'bg-blue-100 text-blue-700';
    default:          return 'bg-neutral-100 text-neutral-500';
  }
}
function statusBadge(status: string) {
  switch (status) {
    case 'completed': return 'bg-green-100 text-green-700';
    case 'pending':   return 'bg-amber-100 text-amber-700';
    case 'failed':    return 'bg-red-100 text-red-700';
    case 'refunded':  return 'bg-blue-100 text-blue-700';
    default:          return 'bg-neutral-100 text-neutral-500';
  }
}
function statusIcon(status: string) {
  switch (status) {
    case 'completed': return <CheckCircle className="w-5 h-5" />;
    case 'pending':   return <Clock className="w-5 h-5" />;
    case 'failed':    return <AlertCircle className="w-5 h-5" />;
    case 'refunded':  return <ArrowDownRight className="w-5 h-5" />;
    default:          return <Clock className="w-5 h-5" />;
  }
}
