import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  CloudSun, Cloud, CloudRain, Sun, Wind, Droplets, MapPin,
  RefreshCw, Eye, Gauge, CloudLightning, CloudSnow,
  CloudFog, AlertTriangle, Search, Loader2, Navigation,
  LocateFixed, WifiOff
} from 'lucide-react';

interface CurrentWeather {
  temperature: number;
  apparent_temperature: number;
  humidity: number;
  wind_speed: number;
  wind_direction: number;
  pressure: number;
  cloud_cover: number;
  visibility: number;
  precipitation: number;
  weather_code: number;
  is_day: boolean;
}

interface DailyForecast {
  date: string;
  weather_code: number;
  temp_max: number;
  temp_min: number;
  precipitation_sum: number;
  precipitation_prob: number;
  wind_speed_max: number;
  sunrise: string;
  sunset: string;
}

interface HourlyForecast {
  time: string;
  temperature: number;
  precipitation_prob: number;
  weather_code: number;
}

interface WeatherData {
  current: CurrentWeather;
  daily: DailyForecast[];
  hourly: HourlyForecast[];
  location: string;
  latitude: number;
  longitude: number;
  lastUpdated: Date;
}

type LocationState =
  | { status: 'asking' }
  | { status: 'denied' }
  | { status: 'loading'; lat: number; lon: number; source: string }
  | { status: 'tracking'; lat: number; lon: number }
  | { status: 'error'; message: string };

const WMO: Record<number, { label: string; Icon: typeof Sun; gradient: string }> = {
  0:  { label: 'Clear sky',              Icon: Sun,          gradient: 'from-amber-400 to-orange-500' },
  1:  { label: 'Mainly clear',           Icon: Sun,          gradient: 'from-amber-400 to-orange-400' },
  2:  { label: 'Partly cloudy',          Icon: CloudSun,     gradient: 'from-sky-400 to-blue-500' },
  3:  { label: 'Overcast',               Icon: Cloud,        gradient: 'from-slate-400 to-slate-600' },
  45: { label: 'Fog',                    Icon: CloudFog,     gradient: 'from-slate-300 to-slate-500' },
  48: { label: 'Rime fog',               Icon: CloudFog,     gradient: 'from-slate-300 to-slate-500' },
  51: { label: 'Light drizzle',          Icon: CloudRain,    gradient: 'from-blue-400 to-blue-600' },
  53: { label: 'Drizzle',                Icon: CloudRain,    gradient: 'from-blue-400 to-blue-600' },
  55: { label: 'Heavy drizzle',          Icon: CloudRain,    gradient: 'from-blue-500 to-blue-700' },
  61: { label: 'Light rain',             Icon: CloudRain,    gradient: 'from-blue-500 to-blue-700' },
  63: { label: 'Rain',                   Icon: CloudRain,    gradient: 'from-blue-500 to-blue-700' },
  65: { label: 'Heavy rain',             Icon: CloudRain,    gradient: 'from-blue-600 to-blue-800' },
  71: { label: 'Light snow',             Icon: CloudSnow,    gradient: 'from-sky-300 to-sky-500' },
  73: { label: 'Snow',                   Icon: CloudSnow,    gradient: 'from-sky-400 to-sky-600' },
  75: { label: 'Heavy snow',             Icon: CloudSnow,    gradient: 'from-sky-500 to-sky-700' },
  77: { label: 'Snow grains',            Icon: CloudSnow,    gradient: 'from-sky-400 to-sky-600' },
  80: { label: 'Rain showers',           Icon: CloudRain,    gradient: 'from-blue-500 to-blue-700' },
  81: { label: 'Rain showers',           Icon: CloudRain,    gradient: 'from-blue-500 to-blue-700' },
  82: { label: 'Violent rain showers',   Icon: CloudRain,    gradient: 'from-blue-600 to-blue-800' },
  85: { label: 'Snow showers',           Icon: CloudSnow,    gradient: 'from-sky-400 to-sky-600' },
  86: { label: 'Heavy snow showers',     Icon: CloudSnow,    gradient: 'from-sky-500 to-sky-700' },
  95: { label: 'Thunderstorm',           Icon: CloudLightning, gradient: 'from-violet-600 to-violet-900' },
  96: { label: 'Thunderstorm + hail',    Icon: CloudLightning, gradient: 'from-violet-700 to-violet-900' },
  99: { label: 'Thunderstorm + hail',    Icon: CloudLightning, gradient: 'from-violet-700 to-violet-900' },
};

function wmo(code: number) {
  // find nearest code (WMO codes have gaps)
  if (WMO[code]) return WMO[code];
  const closest = Object.keys(WMO)
    .map(Number)
    .reduce((a, b) => Math.abs(b - code) < Math.abs(a - code) ? b : a);
  return WMO[closest];
}

function windDir(deg: number) {
  return ['N','NE','E','SE','S','SW','W','NW'][Math.round(deg / 45) % 8];
}

async function fetchWeatherByCoords(lat: number, lon: number): Promise<WeatherData> {
  // Parallel: reverse-geocode + weather
  const [geoRes, wxRes] = await Promise.all([
    fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&zoom=10`,
      { headers: { 'Accept-Language': 'en' } }
    ),
    fetch(
      `https://api.open-meteo.com/v1/forecast` +
      `?latitude=${lat}&longitude=${lon}` +
      `&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover,visibility,is_day` +
      `&hourly=temperature_2m,precipitation_probability,weather_code` +
      `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset` +
      `&timezone=auto&forecast_days=7`
    ),
  ]);

  if (!wxRes.ok) throw new Error('Could not fetch weather data from Open-Meteo.');

  const geoJson = geoRes.ok ? await geoRes.json() : null;
  const wx = await wxRes.json();

  // Parse location name from Nominatim
  let locationName = `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  if (geoJson?.address) {
    const a = geoJson.address;
    const city = a.city || a.town || a.village || a.county || a.state_district || '';
    const state = a.state || '';
    const country = a.country || '';
    locationName = [city, state, country].filter(Boolean).join(', ');
  }

  // Hourly next 24h
  const now = new Date();
  const hourly: HourlyForecast[] = [];
  if (wx.hourly?.time) {
    const start = Math.max(0, wx.hourly.time.findIndex((t: string) => new Date(t) >= now));
    for (let i = start; i < Math.min(start + 24, wx.hourly.time.length); i++) {
      hourly.push({
        time: wx.hourly.time[i],
        temperature: wx.hourly.temperature_2m[i],
        precipitation_prob: wx.hourly.precipitation_probability?.[i] ?? 0,
        weather_code: wx.hourly.weather_code?.[i] ?? 0,
      });
    }
  }

  // Daily 7-day
  const daily: DailyForecast[] = (wx.daily?.time ?? []).map((_: string, i: number) => ({
    date: wx.daily.time[i],
    weather_code: wx.daily.weather_code[i],
    temp_max: wx.daily.temperature_2m_max[i],
    temp_min: wx.daily.temperature_2m_min[i],
    precipitation_sum: wx.daily.precipitation_sum?.[i] ?? 0,
    precipitation_prob: wx.daily.precipitation_probability_max?.[i] ?? 0,
    wind_speed_max: wx.daily.wind_speed_10m_max?.[i] ?? 0,
    sunrise: wx.daily.sunrise?.[i] ?? '',
    sunset: wx.daily.sunset?.[i] ?? '',
  }));

  return {
    current: {
      temperature: wx.current.temperature_2m,
      apparent_temperature: wx.current.apparent_temperature,
      humidity: wx.current.relative_humidity_2m,
      wind_speed: wx.current.wind_speed_10m,
      wind_direction: wx.current.wind_direction_10m,
      pressure: wx.current.pressure_msl,
      cloud_cover: wx.current.cloud_cover,
      visibility: wx.current.visibility,
      precipitation: wx.current.precipitation,
      weather_code: wx.current.weather_code,
      is_day: wx.current.is_day === 1,
    },
    daily,
    hourly,
    location: locationName,
    latitude: lat,
    longitude: lon,
    lastUpdated: new Date(),
  };
}

async function geocodeCity(name: string): Promise<{ lat: number; lon: number; display: string }> {
  // Try Open-Meteo geocoding first
  const res = await fetch(
    `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=3&language=en&format=json`
  );
  const data = await res.json();

  if (data.results?.length) {
    const r = data.results[0];
    const display = [r.name, r.admin1, r.country].filter(Boolean).join(', ');
    return { lat: r.latitude, lon: r.longitude, display };
  }

  // Fallback: Nominatim search
  const nmRes = await fetch(
    `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(name)}&format=json&limit=1&countrycodes=in`,
    { headers: { 'Accept-Language': 'en' } }
  );
  const nmData = await nmRes.json();
  if (nmData?.length) {
    return { lat: parseFloat(nmData[0].lat), lon: parseFloat(nmData[0].lon), display: nmData[0].display_name.split(',').slice(0, 3).join(',') };
  }

  throw new Error(`Could not find "${name}". Try a nearby larger city name.`);
}

export function WeatherPage() {
  const { profile } = useAuth();
  const [locationState, setLocationState] = useState<LocationState>({ status: 'asking' });
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const watchIdRef = useRef<number | null>(null);
  const refreshTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const loadWeather = useCallback(async (lat: number, lon: number) => {
    setWeatherLoading(true);
    setWeatherError(null);
    try {
      const data = await fetchWeatherByCoords(lat, lon);
      setWeather(data);
    } catch (e) {
      setWeatherError(e instanceof Error ? e.message : 'Failed to load weather.');
    } finally {
      setWeatherLoading(false);
    }
  }, []);

  // Start GPS tracking
  const startGPSTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationState({ status: 'denied' });
      return;
    }

    setLocationState({ status: 'asking' });

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude: lat, longitude: lon } = pos.coords;
        setLocationState({ status: 'tracking', lat, lon });
        loadWeather(lat, lon);

        // Watch for position updates (live tracking)
        if (watchIdRef.current !== null) navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = navigator.geolocation.watchPosition(
          (updated) => {
            setLocationState({ status: 'tracking', lat: updated.coords.latitude, lon: updated.coords.longitude });
          },
          () => {},
          { enableHighAccuracy: true, maximumAge: 30000 }
        );

        // Auto-refresh weather every 10 minutes
        if (refreshTimerRef.current) clearInterval(refreshTimerRef.current);
        refreshTimerRef.current = setInterval(() => {
          loadWeather(lat, lon);
        }, 10 * 60 * 1000);
      },
      (err) => {
        if (err.code === GeolocationPositionError.PERMISSION_DENIED) {
          setLocationState({ status: 'denied' });
        } else {
          setLocationState({ status: 'error', message: 'Could not get your location. Please search manually.' });
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }, [loadWeather]);

  // On mount: request GPS immediately
  useEffect(() => {
    startGPSTracking();
    return () => {
      if (watchIdRef.current !== null) navigator.geolocation.clearWatch(watchIdRef.current);
      if (refreshTimerRef.current) clearInterval(refreshTimerRef.current);
    };
  }, [startGPSTracking]);

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setWeatherLoading(true);
    setWeatherError(null);
    try {
      const { lat, lon } = await geocodeCity(searchQuery.trim());
      setSearchQuery('');
      // Stop GPS tracking when user manually searches
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setLocationState({ status: 'loading', lat, lon, source: 'search' });
      const data = await fetchWeatherByCoords(lat, lon);
      setWeather(data);
      setLocationState({ status: 'tracking', lat, lon });
    } catch (err) {
      setWeatherError(err instanceof Error ? err.message : 'Search failed.');
    } finally {
      setWeatherLoading(false);
    }
  }

  // --- RENDER: asking for permission ---
  if (locationState.status === 'asking') {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Weather Dashboard</h2>
          <p className="text-sm text-neutral-500 mt-1">Live weather powered by GPS + Open-Meteo API</p>
        </div>
        <div className="card p-12 flex flex-col items-center text-center gap-4">
          <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center animate-pulse">
            <LocateFixed className="w-10 h-10 text-primary-700" />
          </div>
          <h3 className="text-xl font-bold text-neutral-900">Requesting your location…</h3>
          <p className="text-sm text-neutral-500 max-w-sm">
            Please allow location access when your browser asks. We use your GPS coordinates to show live, accurate weather for exactly where you are.
          </p>
          <Loader2 className="w-6 h-6 text-primary-600 animate-spin" />
        </div>
      </div>
    );
  }

  // --- RENDER: permission denied ---
  if (locationState.status === 'denied') {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Weather Dashboard</h2>
        </div>
        <div className="card p-10 flex flex-col items-center text-center gap-4">
          <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center">
            <WifiOff className="w-8 h-8 text-amber-600" />
          </div>
          <h3 className="text-lg font-bold text-neutral-900">Location access denied</h3>
          <p className="text-sm text-neutral-500 max-w-sm">
            You denied location access. You can still search for any city manually below, or reset location permissions in your browser settings and try again.
          </p>
          <form onSubmit={handleSearch} className="flex gap-2 w-full max-w-sm">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <input
                autoFocus
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="e.g. Vijayawada, Hyderabad…"
                className="input-field pl-9"
              />
            </div>
            <button type="submit" disabled={weatherLoading} className="btn-primary disabled:opacity-60">
              {weatherLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Go'}
            </button>
          </form>
          {weatherError && <p className="text-sm text-red-600">{weatherError}</p>}
          <button onClick={startGPSTracking} className="btn-secondary text-sm">
            <LocateFixed className="w-4 h-4" /> Try GPS again
          </button>
        </div>
      </div>
    );
  }

  // --- RENDER: loading weather (first fetch) ---
  if (weatherLoading && !weather) {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Weather Dashboard</h2>
          <p className="text-sm text-neutral-500 mt-1">Live weather powered by GPS + Open-Meteo API</p>
        </div>
        <div className="card p-12 text-center">
          <Loader2 className="w-10 h-10 mx-auto text-primary-600 animate-spin mb-4" />
          <p className="text-sm font-semibold text-neutral-700">Got your location!</p>
          <p className="text-xs text-neutral-400 mt-1">Fetching live weather data…</p>
        </div>
      </div>
    );
  }

  if (!weather) return null;

  const w = wmo(weather.current.weather_code);
  const CurrentIcon = w.Icon;
  const today = weather.daily[0];
  const alerts = buildAlerts(weather);
  const isTracking = locationState.status === 'tracking';

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Weather Dashboard</h2>
          <div className="flex items-center gap-2 mt-1">
            {isTracking ? (
              <span className="flex items-center gap-1.5 text-xs font-semibold text-primary-700">
                <span className="relative flex w-2.5 h-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75" />
                  <span className="relative inline-flex rounded-full w-2.5 h-2.5 bg-primary-600" />
                </span>
                Live GPS tracking active
              </span>
            ) : (
              <span className="text-xs text-neutral-500">Manual search</span>
            )}
            <span className="text-xs text-neutral-400">· Updated {weather.lastUpdated.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!isTracking && (
            <button onClick={startGPSTracking} className="btn-secondary text-sm py-2">
              <LocateFixed className="w-4 h-4" /> Use my location
            </button>
          )}
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search city…"
                className="input-field pl-9 py-2 text-sm w-44"
              />
            </div>
            <button type="submit" disabled={weatherLoading} className="btn-primary py-2 text-sm disabled:opacity-60">
              {weatherLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Go'}
            </button>
          </form>
        </div>
      </div>

      {weatherError && (
        <div className="flex items-center gap-3 p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-700">
          <AlertTriangle className="w-5 h-5 flex-shrink-0" />
          {weatherError}
        </div>
      )}

      {/* Main weather card */}
      <div className={`rounded-2xl bg-gradient-to-br ${w.gradient} p-6 sm:p-8 text-white shadow-lg`}>
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div>
            <div className="flex items-center gap-1.5 text-sm text-white/80 mb-3">
              <MapPin className="w-4 h-4" />
              <span>{weather.location}</span>
              {isTracking && (
                <span className="ml-1 px-1.5 py-0.5 rounded-full bg-white/20 text-xs font-semibold">
                  GPS
                </span>
              )}
            </div>
            <div className="flex items-center gap-4">
              <CurrentIcon className="w-16 h-16 drop-shadow" />
              <div>
                <div className="text-5xl sm:text-7xl font-extrabold leading-none">
                  {Math.round(weather.current.temperature)}°
                </div>
                <div className="text-white/90 text-lg mt-1">{w.label}</div>
              </div>
            </div>
            <div className="text-sm text-white/75 mt-2">
              Feels like {Math.round(weather.current.apparent_temperature)}°C
              {today && ` · H:${Math.round(today.temp_max)}° L:${Math.round(today.temp_min)}°`}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            <Stat icon={Droplets}  label="Humidity"    value={`${weather.current.humidity}%`} />
            <Stat icon={Wind}      label="Wind"        value={`${Math.round(weather.current.wind_speed)} km/h`} />
            <Stat icon={Navigation} label="Direction"  value={windDir(weather.current.wind_direction)} />
            <Stat icon={Gauge}     label="Pressure"    value={`${Math.round(weather.current.pressure)}`} unit="hPa" />
            <Stat icon={Eye}       label="Visibility"  value={weather.current.visibility ? `${(weather.current.visibility / 1000).toFixed(1)}` : '—'} unit="km" />
            <Stat icon={Cloud}     label="Cloud"       value={`${weather.current.cloud_cover}%`} />
          </div>
        </div>
      </div>

      {/* Sunrise / Sunset / Precipitation row */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Sunrise', value: today?.sunrise ? fmtTime(today.sunrise) : '—', color: 'bg-amber-100 text-amber-600' },
          { label: 'Sunset',  value: today?.sunset  ? fmtTime(today.sunset)  : '—', color: 'bg-orange-100 text-orange-600' },
          { label: 'Rain today', value: `${weather.current.precipitation} mm`, color: 'bg-blue-100 text-blue-600' },
        ].map(item => (
          <div key={item.label} className="card p-4 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${item.color}`}>
              <CloudRain className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs text-neutral-500">{item.label}</div>
              <div className="font-bold text-neutral-900 text-sm">{item.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Hourly */}
      {weather.hourly.length > 0 && (
        <div className="card p-6">
          <h3 className="text-lg font-bold text-neutral-900 mb-4">Next 24 Hours</h3>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {weather.hourly.map((h, i) => {
              const hw = wmo(h.weather_code);
              const HIcon = hw.Icon;
              return (
                <div key={i} className="flex-shrink-0 w-[72px] p-3 rounded-xl bg-neutral-50 hover:bg-neutral-100 transition-colors text-center">
                  <div className="text-[11px] font-semibold text-neutral-500">
                    {i === 0 ? 'Now' : fmtHour(h.time)}
                  </div>
                  <HIcon className="w-6 h-6 mx-auto my-2 text-primary-600" />
                  <div className="text-sm font-bold text-neutral-900">{Math.round(h.temperature)}°</div>
                  {h.precipitation_prob > 0 && (
                    <div className="text-[10px] text-blue-600 font-bold mt-0.5">{h.precipitation_prob}%</div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 7-day */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4">7-Day Forecast</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {weather.daily.map((day, i) => {
            const dw = wmo(day.weather_code);
            const DIcon = dw.Icon;
            return (
              <div key={i} className={`p-4 rounded-xl text-center transition-colors ${i === 0 ? 'bg-primary-50 border-2 border-primary-200' : 'bg-neutral-50 hover:bg-neutral-100'}`}>
                <div className="text-xs font-bold text-neutral-600 uppercase">
                  {i === 0 ? 'Today' : fmtDay(day.date)}
                </div>
                <DIcon className="w-8 h-8 mx-auto my-2 text-primary-600" />
                <div className="text-base font-extrabold text-neutral-900">{Math.round(day.temp_max)}°</div>
                <div className="text-xs text-neutral-400">{Math.round(day.temp_min)}°</div>
                {day.precipitation_prob > 0 && (
                  <div className="text-[11px] text-blue-600 font-semibold mt-1">{day.precipitation_prob}% rain</div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Farming alerts */}
      <div>
        <h3 className="text-lg font-bold text-neutral-900 mb-3">Farming Alerts</h3>
        <div className="space-y-2">
          {alerts.map((a, i) => (
            <div key={i} className={`card p-4 border-l-4 ${SEVERITY_STYLES[a.severity]}`}>
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-sm">{a.title}</div>
                  <div className="text-sm text-neutral-600 mt-0.5">{a.desc}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Refresh */}
      <div className="flex justify-center">
        <button
          disabled={weatherLoading}
          onClick={() => loadWeather(weather.latitude, weather.longitude)}
          className="btn-secondary disabled:opacity-60"
        >
          <RefreshCw className={`w-4 h-4 ${weatherLoading ? 'animate-spin' : ''}`} />
          Refresh now
        </button>
      </div>
    </div>
  );
}

const SEVERITY_STYLES: Record<string, string> = {
  high:   'border-l-red-500    bg-red-50    text-red-800',
  medium: 'border-l-amber-500  bg-amber-50  text-amber-800',
  low:    'border-l-primary-500 bg-primary-50 text-primary-800',
};

function Stat({ icon: Icon, label, value, unit }: { icon: typeof Droplets; label: string; value: string; unit?: string }) {
  return (
    <div className="bg-white/15 backdrop-blur-sm rounded-xl p-2.5 text-center">
      <Icon className="w-4 h-4 mx-auto mb-1 text-white/70" />
      <div className="text-[10px] text-white/60 leading-none">{label}</div>
      <div className="text-xs font-bold mt-0.5">{value}{unit ? <span className="font-normal opacity-70"> {unit}</span> : ''}</div>
    </div>
  );
}

function fmtTime(s: string) { return new Date(s).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }); }
function fmtHour(s: string) { return new Date(s).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }); }
function fmtDay(s: string)  { return new Date(s).toLocaleDateString('en-IN', { weekday: 'short' }); }

function buildAlerts(weather: WeatherData) {
  const alerts: { severity: string; title: string; desc: string }[] = [];
  const c = weather.current;

  const rainDays = weather.daily.filter(d => d.precipitation_prob >= 50);
  if (rainDays.length) {
    alerts.push({ severity: 'high', title: `Rain likely ${fmtDay(rainDays[0].date)}`, desc: `${rainDays[0].precipitation_prob}% probability, ~${rainDays[0].precipitation_sum}mm. Postpone spraying; harvest ripe crops early.` });
  }
  if (c.weather_code >= 95) {
    alerts.push({ severity: 'high', title: 'Thunderstorm detected nearby', desc: 'Avoid open fields and metal tools. Secure equipment and move livestock to shelter.' });
  }
  if (c.temperature >= 35) {
    alerts.push({ severity: 'high', title: `High heat — ${Math.round(c.temperature)}°C`, desc: 'Avoid field work 11 AM–3 PM. Increase irrigation. Protect seedlings with shade cloth.' });
  } else if (c.temperature >= 30) {
    alerts.push({ severity: 'medium', title: `Warm conditions — ${Math.round(c.temperature)}°C`, desc: 'Monitor soil moisture closely. Early morning or evening work is recommended.' });
  }
  if (c.wind_speed >= 30) {
    alerts.push({ severity: 'high', title: `Strong winds — ${Math.round(c.wind_speed)} km/h`, desc: 'Do not spray pesticides or fertilizers. Secure loose covers and structures.' });
  }
  if (c.humidity < 30) {
    alerts.push({ severity: 'medium', title: `Low humidity — ${c.humidity}%`, desc: 'Increase irrigation frequency. Mulch topsoil to prevent moisture loss.' });
  }
  if (alerts.length === 0) {
    alerts.push({ severity: 'low', title: 'Good conditions for farming', desc: `Clear weather with ${Math.round(c.temperature)}°C and ${Math.round(c.wind_speed)} km/h winds. Suitable for most field activities.` });
  }
  return alerts;
}
