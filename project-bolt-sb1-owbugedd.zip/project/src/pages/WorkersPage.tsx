import { useEffect, useState } from 'react';
import { supabase, type Worker } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Users, Plus, Search, MapPin, Star, X } from 'lucide-react';
import { CheckoutModal } from '../components/CheckoutModal';

export function WorkersPage() {
  const { profile } = useAuth();
  const [workers, setWorkers] = useState<(Worker & { profiles?: any })[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [checkoutItem, setCheckoutItem] = useState<(Worker & { profiles?: any }) | null>(null);

  useEffect(() => { loadWorkers(); }, [search]);

  async function loadWorkers() {
    let query = supabase.from('workers').select('*, profiles!workers_user_id_fkey(full_name, location, phone)').order('created_at', { ascending: false });
    if (search) query = query.ilike('skills', `%${search}%`);
    const { data, error } = await query;
    if (error) console.error(error);
    setWorkers(data ?? []);
    setLoading(false);
  }

  const isWorker = profile?.role === 'worker';

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Workforce Marketplace</h2>
          <p className="text-sm text-neutral-500 mt-1">Hire skilled farm workers by the day</p>
        </div>
        {isWorker && (
          <button onClick={() => setShowAdd(true)} className="btn-primary">
            <Plus className="w-5 h-5" /> Create Worker Profile
          </button>
        )}
      </div>

      <div className="card p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
          <input type="text" placeholder="Search by skills (e.g. harvesting, plowing...)" value={search} onChange={(e) => setSearch(e.target.value)} className="input-field pl-10 py-2.5" />
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading workers...</div>
      ) : workers.length === 0 ? (
        <div className="card p-12 text-center">
          <Users className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No workers found</h3>
          <p className="text-sm text-neutral-500 mt-1">Try a different search or create your worker profile.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {workers.map((w) => (
            <div key={w.id} className="card p-5">
              <div className="flex items-start gap-3">
                <div className="w-14 h-14 rounded-2xl bg-green-100 flex items-center justify-center text-lg font-bold text-green-700 flex-shrink-0">
                  {w.profiles?.full_name?.charAt(0).toUpperCase() ?? 'W'}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-neutral-900 truncate">{w.profiles?.full_name ?? 'Unknown Worker'}</h3>
                  {w.location && <div className="flex items-center gap-1 text-sm text-neutral-500 mt-0.5"><MapPin className="w-3.5 h-3.5" /> {w.location}</div>}
                </div>
                <span className={`badge ${w.available ? 'bg-green-100 text-green-700' : 'bg-neutral-100 text-neutral-500'}`}>
                  {w.available ? 'Available' : 'Busy'}
                </span>
              </div>

              <div className="mt-4 flex flex-wrap gap-1.5">
                {w.skills.split(',').map((s, i) => (
                  <span key={i} className="badge bg-amber-50 text-amber-700 border border-amber-200">{s.trim()}</span>
                ))}
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div className="p-3 rounded-xl bg-neutral-50">
                  <div className="text-xs text-neutral-500">Experience</div>
                  <div className="font-bold text-neutral-900">{w.experience_years} yrs</div>
                </div>
                <div className="p-3 rounded-xl bg-green-50">
                  <div className="text-xs text-neutral-500">Daily Wage</div>
                  <div className="font-bold text-green-700">₹{w.daily_wage}/day</div>
                </div>
              </div>

              <div className="flex items-center gap-1 mt-3 text-sm">
                <Star className="w-4 h-4 text-amber-400 fill-current" />
                <span className="font-semibold text-neutral-700">4.2</span>
                <span className="text-neutral-400">(8 reviews)</span>
              </div>

              {profile?.role === 'farmer' && (
                <button onClick={() => setCheckoutItem(w)} disabled={!w.available} className="btn-primary w-full justify-center mt-4 text-sm py-2.5 disabled:opacity-50">{w.available ? 'Hire Worker' : 'Unavailable'}</button>
              )}
            </div>
          ))}
        </div>
      )}

      {showAdd && <AddWorkerModal onClose={() => { setShowAdd(false); loadWorkers(); }} />}
      {checkoutItem && (
        <CheckoutModal
          item={{ name: checkoutItem.profiles?.full_name ?? 'Worker', type: 'worker', dailyRate: checkoutItem.daily_wage, days: 1, listingId: checkoutItem.id }}
          onClose={() => setCheckoutItem(null)}
          onSuccess={() => { setCheckoutItem(null); loadWorkers(); }}
        />
      )}
    </div>
  );
}

function AddWorkerModal({ onClose }: { onClose: () => void }) {
  const { session } = useAuth();
  const [skills, setSkills] = useState('');
  const [dailyWage, setDailyWage] = useState('');
  const [experience, setExperience] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.from('workers').insert({
      user_id: session!.user.id,
      skills,
      daily_wage: parseFloat(dailyWage),
      experience_years: parseInt(experience) || 0,
      location,
    });
    if (error) { setError(error.message); setLoading(false); }
    else { onClose(); }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900">Create Worker Profile</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>}
          <div>
            <label className="label">Skills (comma-separated)</label>
            <input type="text" required value={skills} onChange={(e) => setSkills(e.target.value)} placeholder="harvesting, plowing, irrigation" className="input-field" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Daily Wage (₹)</label>
              <input type="number" required value={dailyWage} onChange={(e) => setDailyWage(e.target.value)} placeholder="500" className="input-field" />
            </div>
            <div>
              <label className="label">Experience (years)</label>
              <input type="number" value={experience} onChange={(e) => setExperience(e.target.value)} placeholder="5" className="input-field" />
            </div>
          </div>
          <div>
            <label className="label">Location</label>
            <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, State" className="input-field" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 rounded-xl font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">{loading ? 'Creating...' : 'Create Profile'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
