import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { supabase, type AIRecommendation } from '../lib/supabase';
import { Sparkles, Tractor, Users, Truck, Sprout, CloudRain, X, TrendingUp, ArrowRight, Brain } from 'lucide-react';

const TYPE_ICONS: Record<string, typeof Tractor> = {
  equipment: Tractor,
  worker: Users,
  transport: Truck,
  crop: Sprout,
  weather_alert: CloudRain,
};

const TYPE_COLORS: Record<string, string> = {
  equipment: 'bg-green-100 text-green-700',
  worker: 'bg-amber-100 text-amber-700',
  transport: 'bg-blue-100 text-blue-700',
  crop: 'bg-green-100 text-green-700',
  weather_alert: 'bg-blue-100 text-blue-700',
};

const TYPE_LABELS: Record<string, string> = {
  equipment: 'Equipment',
  worker: 'Worker',
  transport: 'Transport',
  crop: 'Crop',
  weather_alert: 'Weather Alert',
};

export function RecommendationsPage() {
  const { session } = useAuth();
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => { loadRecommendations(); }, []);

  async function loadRecommendations() {
    if (!session?.user?.id) return;
    const { data, error } = await supabase
      .from('ai_recommendations')
      .select('*')
      .eq('user_id', session.user.id)
      .eq('is_dismissed', false)
      .order('created_at', { ascending: false });

    if (error) console.error(error);
    setRecommendations(data as AIRecommendation[] ?? []);
    setLoading(false);
  }

  async function generateRecommendations() {
    setGenerating(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-recommendations`;
      const headers = {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({ userId: session!.user.id }),
      });

      if (!response.ok) throw new Error(`Request failed (${response.status})`);
      const result = await response.json();

      if (result.recommendations) {
        for (const rec of result.recommendations) {
          await supabase.from('ai_recommendations').insert({
            user_id: session!.user.id,
            type: rec.type,
            title: rec.title,
            description: rec.description,
            confidence_score: rec.confidence_score ?? 0.75,
            metadata: rec.metadata ?? null,
          });
        }
        await loadRecommendations();
      }
    } catch (err) {
      console.error('Failed to generate recommendations:', err);
      // Fallback: generate local recommendations
      const fallbackRecs = generateFallbackRecommendations();
      for (const rec of fallbackRecs) {
        await supabase.from('ai_recommendations').insert({
          user_id: session!.user.id,
          type: rec.type,
          title: rec.title,
          description: rec.description,
          confidence_score: rec.confidence_score,
          metadata: rec.metadata,
        });
      }
      await loadRecommendations();
    }
    setGenerating(false);
  }

  async function dismissRecommendation(id: string) {
    await supabase.from('ai_recommendations').update({ is_dismissed: true }).eq('id', id);
    setRecommendations(prev => prev.filter(r => r.id !== id));
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900 flex items-center gap-2">
            <Brain className="w-7 h-7 text-green-700" /> AI Recommendations
          </h2>
          <p className="text-sm text-neutral-500 mt-1">Personalized suggestions powered by AI to optimize your farming</p>
        </div>
        <button onClick={generateRecommendations} disabled={generating} className="btn-primary disabled:opacity-60">
          <Sparkles className="w-5 h-5" /> {generating ? 'Analyzing...' : 'Generate Recommendations'}
        </button>
      </div>

      {/* AI banner */}
      <div className="rounded-2xl bg-gradient-to-r from-green-800 via-green-700 to-green-600 p-6 text-white">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center flex-shrink-0">
            <Brain className="w-7 h-7 text-green-200" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Smart Farming Assistant</h3>
            <p className="text-green-100 text-sm mt-1">
              Our AI analyzes your booking history, location, weather patterns, and seasonal trends to suggest the best equipment, workers, and crops for your farm.
            </p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading recommendations...</div>
      ) : recommendations.length === 0 ? (
        <div className="card p-12 text-center">
          <Sparkles className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No recommendations yet</h3>
          <p className="text-sm text-neutral-500 mt-1 mb-4">Click "Generate Recommendations" to get AI-powered suggestions.</p>
          <button onClick={generateRecommendations} disabled={generating} className="btn-primary disabled:opacity-60">
            <Sparkles className="w-5 h-5" /> {generating ? 'Analyzing...' : 'Generate Now'}
          </button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-5">
          {recommendations.map((rec) => {
            const Icon = TYPE_ICONS[rec.type] ?? Tractor;
            const colors = TYPE_COLORS[rec.type] ?? TYPE_COLORS.equipment;
            const confidence = Math.round(rec.confidence_score * 100);
            return (
              <div key={rec.id} className="card p-5 group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${colors}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="badge bg-neutral-100 text-neutral-600">{TYPE_LABELS[rec.type]}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => dismissRecommendation(rec.id)}
                    className="p-1.5 rounded-lg text-neutral-300 hover:text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <h3 className="font-bold text-neutral-900">{rec.title}</h3>
                <p className="text-sm text-neutral-500 mt-1 leading-relaxed">{rec.description}</p>

                {/* Confidence bar */}
                <div className="mt-4">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-neutral-500 flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Confidence</span>
                    <span className="font-bold text-neutral-700">{confidence}%</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-neutral-100 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${confidence >= 80 ? 'bg-green-500' : confidence >= 60 ? 'bg-amber-500' : 'bg-neutral-400'}`}
                      style={{ width: `${confidence}%` }}
                    />
                  </div>
                </div>

                <button className="mt-4 w-full py-2.5 rounded-xl text-sm font-semibold text-green-700 bg-green-50 hover:bg-green-100 transition-colors flex items-center justify-center gap-1">
                  View Details <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function generateFallbackRecommendations() {
  return [
    {
      type: 'equipment' as const,
      title: 'Rotavator recommended for your field',
      description: 'Based on your location and current season, a rotavator would help prepare your field for the upcoming Rabi crop. Available near you from ₹600/day.',
      confidence_score: 0.85,
      metadata: { category: 'Rotavator', season: 'Rabi' },
    },
    {
      type: 'crop' as const,
      title: 'Wheat is ideal for this season',
      description: 'Weather patterns and soil conditions in your area are optimal for wheat cultivation. Expected yield: 4-5 tons/hectare.',
      confidence_score: 0.78,
      metadata: { crop: 'Wheat', season: 'Rabi' },
    },
    {
      type: 'weather_alert' as const,
      title: 'Rain expected in 3 days — plan accordingly',
      description: '65% chance of rainfall Wednesday-Thursday. Consider harvesting mature crops and delaying any spraying activities.',
      confidence_score: 0.72,
      metadata: { alert_type: 'rain', days: 3 },
    },
    {
      type: 'worker' as const,
      title: 'Harvesting workers available nearby',
      description: '5 skilled harvesting workers are available within 10km of your location. Average daily wage: ₹450/day.',
      confidence_score: 0.68,
      metadata: { skill: 'harvesting', nearby: '10km' },
    },
  ];
}
