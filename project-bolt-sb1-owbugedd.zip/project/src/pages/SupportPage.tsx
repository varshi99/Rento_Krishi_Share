import { useEffect, useState, type FormEvent } from 'react';
import { supabase, type SupportTicket } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { LifeBuoy, Plus, X, AlertCircle, CheckCircle, Clock, MessageCircle, HelpCircle } from 'lucide-react';

export function SupportPage() {
  const { session } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => { loadTickets(); }, []);

  async function loadTickets() {
    if (!session?.user?.id) return;
    const { data, error } = await supabase.from('support_tickets').select('*').eq('user_id', session.user.id).order('created_at', { ascending: false });
    if (error) console.error(error);
    setTickets(data ?? []);
    setLoading(false);
  }

  const faqs = [
    { q: 'How do I rent equipment?', a: 'Browse the Equipment page, select an item, choose your dates, and click Book Now. You\'ll receive a confirmation once the owner accepts.' },
    { q: 'How do I list my equipment?', a: 'Register as an Equipment Owner, go to your Dashboard, and click "Add Equipment". Fill in the details and submit.' },
    { q: 'What payment methods are accepted?', a: 'We support UPI and all major credit/debit cards through Razorpay.' },
    { q: 'How do I hire a worker?', a: 'Visit the Workers marketplace, search by skills, and click "Hire Worker" on the profile that matches your needs.' },
    { q: 'Can I share a booking with nearby farmers?', a: 'Yes! Use the Shared Booking feature to split costs with other farmers in your area.' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Emergency Support</h2>
          <p className="text-sm text-neutral-500 mt-1">Get help with bookings, payments, or any issues</p>
        </div>
        <button onClick={() => setShowAdd(true)} className="btn-primary"><Plus className="w-5 h-5" /> Raise Ticket</button>
      </div>

      {/* Support options */}
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="card p-5 text-center">
          <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center mx-auto mb-3"><LifeBuoy className="w-6 h-6 text-green-700" /></div>
          <h3 className="font-bold text-neutral-900">Help Center</h3>
          <p className="text-sm text-neutral-500 mt-1">Browse FAQs and guides</p>
        </div>
        <div className="card p-5 text-center">
          <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center mx-auto mb-3"><MessageCircle className="w-6 h-6 text-amber-600" /></div>
          <h3 className="font-bold text-neutral-900">Live Chat</h3>
          <p className="text-sm text-neutral-500 mt-1">Chat with our support team</p>
        </div>
        <div className="card p-5 text-center">
          <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mx-auto mb-3"><AlertCircle className="w-6 h-6 text-blue-700" /></div>
          <h3 className="font-bold text-neutral-900">Raise Ticket</h3>
          <p className="text-sm text-neutral-500 mt-1">Report an issue or concern</p>
        </div>
      </div>

      {/* My tickets */}
      <div className="card p-6">
        <h3 className="text-lg font-bold text-neutral-900 mb-4">My Support Tickets</h3>
        {loading ? (
          <div className="text-center py-8 text-neutral-400">Loading tickets...</div>
        ) : tickets.length === 0 ? (
          <div className="text-center py-8">
            <LifeBuoy className="w-12 h-12 mx-auto text-neutral-300 mb-3" />
            <p className="text-sm text-neutral-500">No support tickets yet. Everything looking good!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {tickets.map(t => (
              <div key={t.id} className="flex items-center gap-4 p-3 rounded-xl bg-neutral-50">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusBg(t.status)}`}>
                  {getStatusIcon(t.status)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm text-neutral-900">{t.subject}</div>
                  {t.description && <div className="text-xs text-neutral-500 truncate">{t.description}</div>}
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`badge capitalize ${getStatusBg(t.status)}`}>{t.status.replace('_', ' ')}</span>
                  <span className={`badge ${getPriorityBg(t.priority)} capitalize`}>{t.priority}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* FAQ */}
      <div>
        <h3 className="text-lg font-bold text-neutral-900 mb-4 flex items-center gap-2"><HelpCircle className="w-5 h-5 text-green-700" /> Frequently Asked Questions</h3>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="card p-5">
              <div className="font-semibold text-neutral-900 mb-1">{faq.q}</div>
              <div className="text-sm text-neutral-600">{faq.a}</div>
            </div>
          ))}
        </div>
      </div>

      {showAdd && <AddTicketModal onClose={() => { setShowAdd(false); loadTickets(); }} />}
    </div>
  );
}

function AddTicketModal({ onClose }: { onClose: () => void }) {
  const { session } = useAuth();
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.from('support_tickets').insert({
      user_id: session!.user.id,
      subject,
      description,
      priority,
    });
    if (error) { setError(error.message); setLoading(false); }
    else { onClose(); }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900">Raise Support Ticket</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>}
          <div>
            <label className="label">Subject</label>
            <input type="text" required value={subject} onChange={e => setSubject(e.target.value)} placeholder="Brief description of the issue" className="input-field" />
          </div>
          <div>
            <label className="label">Description</label>
            <textarea required value={description} onChange={e => setDescription(e.target.value)} rows={4} placeholder="Describe your issue in detail..." className="input-field resize-none" />
          </div>
          <div>
            <label className="label">Priority</label>
            <select value={priority} onChange={e => setPriority(e.target.value as any)} className="input-field">
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 rounded-xl font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">{loading ? 'Submitting...' : 'Submit Ticket'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function getStatusBg(status: string) {
  switch (status) {
    case 'resolved': return 'bg-green-100 text-green-700';
    case 'in_progress': return 'bg-amber-100 text-amber-700';
    case 'closed': return 'bg-neutral-100 text-neutral-500';
    default: return 'bg-blue-100 text-blue-700';
  }
}
function getPriorityBg(priority: string) {
  switch (priority) {
    case 'high': return 'bg-red-100 text-red-700';
    case 'medium': return 'bg-amber-100 text-amber-700';
    default: return 'bg-green-100 text-green-700';
  }
}
function getStatusIcon(status: string) {
  switch (status) {
    case 'resolved': return <CheckCircle className="w-5 h-5" />;
    case 'in_progress': return <Clock className="w-5 h-5" />;
    default: return <AlertCircle className="w-5 h-5" />;
  }
}
