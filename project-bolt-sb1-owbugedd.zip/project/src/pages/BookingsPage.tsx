import { useEffect, useState } from 'react';
import { supabase, type Booking } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Calendar, CheckCircle, Clock, AlertCircle, XCircle } from 'lucide-react';

export function BookingsPage() {
  const { session } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => { loadBookings(); }, []);

  async function loadBookings() {
    if (!session?.user?.id) return;
    const { data, error } = await supabase.from('bookings').select('*').eq('booker_id', session.user.id).order('created_at', { ascending: false });
    if (error) console.error(error);
    setBookings(data ?? []);
    setLoading(false);
  }

  const filtered = filter === 'all' ? bookings : bookings.filter(b => b.status === filter);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h2 className="text-2xl font-extrabold text-neutral-900">My Bookings</h2>
        <p className="text-sm text-neutral-500 mt-1">View and manage all your bookings</p>
      </div>

      {/* Filter tabs */}
      <div className="flex flex-wrap gap-2">
        {['all', 'pending', 'confirmed', 'completed', 'cancelled'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold capitalize transition-colors ${filter === f ? 'bg-green-700 text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
          >
            {f}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading bookings...</div>
      ) : filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <Calendar className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No bookings found</h3>
          <p className="text-sm text-neutral-500 mt-1">Start by browsing equipment, workers, or transport.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((b) => (
            <div key={b.id} className="card p-5 flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${getStatusBg(b.status)}`}>
                {getStatusIcon(b.status)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-neutral-900 capitalize">{b.listing_type} Booking</div>
                <div className="text-sm text-neutral-500">{b.start_date} → {b.end_date}</div>
                {b.notes && <div className="text-xs text-neutral-400 mt-1">{b.notes}</div>}
              </div>
              <div className="text-right">
                <div className="text-lg font-extrabold text-neutral-900">₹{b.total_cost}</div>
                <span className={`badge ${getStatusBadge(b.status)} capitalize`}>{b.status}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function getStatusBg(status: string) {
  switch (status) {
    case 'confirmed': return 'bg-green-100 text-green-700';
    case 'completed': return 'bg-blue-100 text-blue-700';
    case 'pending': return 'bg-amber-100 text-amber-700';
    case 'cancelled': return 'bg-red-100 text-red-700';
    default: return 'bg-neutral-100 text-neutral-500';
  }
}
function getStatusBadge(status: string) {
  switch (status) {
    case 'confirmed': return 'bg-green-100 text-green-700';
    case 'completed': return 'bg-blue-100 text-blue-700';
    case 'pending': return 'bg-amber-100 text-amber-700';
    case 'cancelled': return 'bg-red-100 text-red-700';
    default: return 'bg-neutral-100 text-neutral-500';
  }
}
function getStatusIcon(status: string) {
  switch (status) {
    case 'confirmed': return <CheckCircle className="w-6 h-6" />;
    case 'completed': return <CheckCircle className="w-6 h-6" />;
    case 'pending': return <Clock className="w-6 h-6" />;
    case 'cancelled': return <XCircle className="w-6 h-6" />;
    default: return <AlertCircle className="w-6 h-6" />;
  }
}
