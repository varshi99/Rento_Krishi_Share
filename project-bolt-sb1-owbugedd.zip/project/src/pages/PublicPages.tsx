import { Link } from 'react-router-dom';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { EquipmentPage } from './EquipmentPage';
import { WorkersPage } from './WorkersPage';
import { TransportPage } from './TransportPage';
import { WeatherPage } from './WeatherPage';
import { CropAdvisoryPage } from './CropAdvisoryPage';
import { useAuth } from '../context/AuthContext';
import { ArrowRight } from 'lucide-react';

function PublicPageWrapper({ title, subtitle, children, ctaText, ctaLink }: { title: string; subtitle: string; children: React.ReactNode; ctaText: string; ctaLink: string }) {
  const { session } = useAuth();
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-extrabold text-green-950">{title}</h1>
          <p className="mt-2 text-neutral-500">{subtitle}</p>
        </div>
        {children}
        {!session && (
          <div className="mt-8 rounded-2xl bg-gradient-to-r from-green-700 to-green-800 p-6 text-white text-center">
            <h3 className="text-lg font-bold">Ready to start booking?</h3>
            <p className="text-green-100 text-sm mt-1 mb-4">Create a free account to book equipment, workers, and transport.</p>
            <Link to={ctaLink} className="btn-amber inline-flex">
              {ctaText} <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}

export function PublicEquipmentPage() {
  return <PublicPageWrapper title="Equipment Rental" subtitle="Browse and book farm equipment near you" ctaText="Get Started Free" ctaLink="/register"><EquipmentPage /></PublicPageWrapper>;
}
export function PublicWorkersPage() {
  return <PublicPageWrapper title="Workforce Marketplace" subtitle="Hire skilled farm workers by the day" ctaText="Get Started Free" ctaLink="/register"><WorkersPage /></PublicPageWrapper>;
}
export function PublicTransportPage() {
  return <PublicPageWrapper title="Transport Services" subtitle="Book vehicles for pickup, delivery, and transport" ctaText="Get Started Free" ctaLink="/register"><TransportPage /></PublicPageWrapper>;
}
export function PublicWeatherPage() {
  return <PublicPageWrapper title="Weather Dashboard" subtitle="Live weather and farming alerts for your area" ctaText="Sign Up for Alerts" ctaLink="/register"><WeatherPage /></PublicPageWrapper>;
}
export function PublicCropAdvisoryPage() {
  return <PublicPageWrapper title="Crop Advisory" subtitle="Expert guidance on crops, fertilizers, pest management, and seasonal practices" ctaText="Get Started Free" ctaLink="/register"><CropAdvisoryPage /></PublicPageWrapper>;
}
