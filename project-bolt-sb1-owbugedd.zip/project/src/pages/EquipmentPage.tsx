import { useEffect, useState } from 'react';
import { supabase, type Equipment } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { Tractor, Plus, Search, MapPin, Star, X } from 'lucide-react';
import { CheckoutModal } from '../components/CheckoutModal';

const CATEGORIES = ['Tractor', 'Harvester', 'Tiller', 'Seeder', 'Sprayer', 'Water Pump', 'Thresher', 'Other'];

export function EquipmentPage() {
  const { profile, session } = useAuth();
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [showAdd, setShowAdd] = useState(false);
  const [checkoutItem, setCheckoutItem] = useState<Equipment | null>(null);
  const [myListings, setMyListings] = useState(false);

  useEffect(() => {
    loadEquipment();
  }, [search, category, myListings]);

  async function loadEquipment() {
    let query = supabase.from('equipment').select('*').order('created_at', { ascending: false });

    if (myListings && session?.user?.id) {
      query = query.eq('owner_id', session.user.id);
    }
    if (category !== 'all') {
      query = query.eq('category', category);
    }
    if (search) {
      query = query.ilike('name', `%${search}%`);
    }

    const { data, error } = await query;
    if (error) {
      console.error(error);
    }
    setEquipment(data ?? []);
    setLoading(false);
  }

  const isOwner = profile?.role === 'equipment_owner' || profile?.role === 'admin';

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-neutral-900">Equipment Rental</h2>
          <p className="text-sm text-neutral-500 mt-1">Browse and book farm equipment near you</p>
        </div>
        {isOwner && (
          <button onClick={() => setShowAdd(true)} className="btn-primary">
            <Plus className="w-5 h-5" /> Add Equipment
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input
              type="text"
              placeholder="Search equipment..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-field pl-10 py-2.5"
            />
          </div>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="input-field py-2.5 w-auto"
          >
            <option value="all">All Categories</option>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          {isOwner && (
            <label className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-neutral-300 text-sm font-medium text-neutral-700 cursor-pointer hover:bg-neutral-50">
              <input type="checkbox" checked={myListings} onChange={(e) => setMyListings(e.target.checked)} className="rounded text-green-600 focus:ring-green-500" />
              My Listings
            </label>
          )}
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="text-center py-12 text-neutral-400">Loading equipment...</div>
      ) : equipment.length === 0 ? (
        <div className="card p-12 text-center">
          <Tractor className="w-16 h-16 mx-auto text-neutral-300 mb-4" />
          <h3 className="text-lg font-bold text-neutral-900">No equipment found</h3>
          <p className="text-sm text-neutral-500 mt-1">Try adjusting your filters or add your own equipment.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {equipment.map((item) => (
            <div key={item.id} className="card overflow-hidden group">
              <div className="h-44 bg-gradient-to-br from-green-100 to-amber-100 flex items-center justify-center relative overflow-hidden">
                {item.image_url ? (
                  <img src={item.image_url} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                ) : (
                  <Tractor className="w-16 h-16 text-green-300" />
                )}
                <div className="absolute top-3 right-3">
                  <span className={`badge ${item.available ? 'bg-green-100 text-green-700' : 'bg-neutral-100 text-neutral-500'}`}>
                    {item.available ? 'Available' : 'Booked'}
                  </span>
                </div>
              </div>
              <div className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-neutral-900">{item.name}</h3>
                    <span className="text-xs font-semibold text-green-700 bg-green-50 px-2 py-0.5 rounded-full">{item.category}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-extrabold text-green-700">₹{item.daily_rate}</div>
                    <div className="text-xs text-neutral-500">per day</div>
                  </div>
                </div>
                {item.description && <p className="text-sm text-neutral-500 mt-2 line-clamp-2">{item.description}</p>}
                {item.location && (
                  <div className="flex items-center gap-1 mt-3 text-sm text-neutral-500">
                    <MapPin className="w-4 h-4" /> {item.location}
                  </div>
                )}
                <div className="flex items-center gap-1 mt-2 text-sm">
                  <Star className="w-4 h-4 text-amber-400 fill-current" />
                  <span className="font-semibold text-neutral-700">4.5</span>
                  <span className="text-neutral-400">(12 reviews)</span>
                </div>
                <button onClick={() => setCheckoutItem(item)} className="btn-primary w-full justify-center mt-4 text-sm py-2.5">
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Equipment Modal */}
      {showAdd && <AddEquipmentModal onClose={() => { setShowAdd(false); loadEquipment(); }} />}
      {checkoutItem && (
        <CheckoutModal
          item={{ name: checkoutItem.name, type: 'equipment', dailyRate: checkoutItem.daily_rate, days: 1, listingId: checkoutItem.id }}
          onClose={() => setCheckoutItem(null)}
          onSuccess={() => { setCheckoutItem(null); loadEquipment(); }}
        />
      )}
    </div>
  );
}

function AddEquipmentModal({ onClose }: { onClose: () => void }) {
  const { session } = useAuth();
  const [name, setName] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [description, setDescription] = useState('');
  const [dailyRate, setDailyRate] = useState('');
  const [location, setLocation] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = await supabase.from('equipment').insert({
      owner_id: session!.user.id,
      name,
      category,
      description,
      daily_rate: parseFloat(dailyRate),
      location,
      image_url: imageUrl || null,
    });

    if (error) {
      setError(error.message);
      setLoading(false);
    } else {
      onClose();
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold text-neutral-900">Add New Equipment</h3>
          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:bg-neutral-100"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>}
          <div>
            <label className="label">Equipment Name</label>
            <input type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Mahindra 575 DI Tractor" className="input-field" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Category</label>
              <select value={category} onChange={(e) => setCategory(e.target.value)} className="input-field">
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Daily Rate (₹)</label>
              <input type="number" required value={dailyRate} onChange={(e) => setDailyRate(e.target.value)} placeholder="800" className="input-field" />
            </div>
          </div>
          <div>
            <label className="label">Description</label>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Describe your equipment..." className="input-field resize-none" />
          </div>
          <div>
            <label className="label">Location</label>
            <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City, State" className="input-field" />
          </div>
          <div>
            <label className="label">Image URL (optional)</label>
            <input type="url" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} placeholder="https://..." className="input-field" />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 px-4 py-3 rounded-xl font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors">Cancel</button>
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center disabled:opacity-60">{loading ? 'Adding...' : 'Add Equipment'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
