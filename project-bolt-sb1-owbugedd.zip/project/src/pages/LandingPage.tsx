import { Link } from 'react-router-dom';

import { useAuth } from '../context/AuthContext';
import {
  Tractor, Users, Truck, CloudSun, Sprout, Star, Shield, ArrowRight,
  Search, Calendar, Wallet, MapPin, TrendingUp, LifeBuoy, Share2, Bell
} from 'lucide-react';

export function LandingPage() {
  const { session } = useAuth();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-50 via-white to-amber-50">
        <div className="absolute inset-0 opacity-5">
          <svg className="w-full h-full" viewBox="0 0 800 600" preserveAspectRatio="xMidYMid slice">
            <defs>
              <pattern id="pattern" width="40" height="40" patternUnits="userSpaceOnUse">
                <circle cx="20" cy="20" r="1.5" fill="#2d8a3e" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#pattern)" />
          </svg>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-up">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-green-100 text-green-800 text-sm font-semibold mb-6">
                <Sprout className="w-4 h-4" />
                India's Agriculture Sharing Platform
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-green-950 leading-tight tracking-tight">
                Rent Anything.<br />
                Hire Anyone.<br />
                <span className="text-green-700">Work Together.</span>
              </h1>
              <p className="mt-6 text-lg text-neutral-600 leading-relaxed max-w-xl">
                Rento KrishiShare connects farmers with equipment owners, skilled workers, and transport providers. Share resources, reduce costs, and grow together.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link to={session ? "/dashboard" : "/register"} className="btn-primary text-base">
                  Get Started Free
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link to="/equipment" className="btn-secondary text-base">
                  <Search className="w-5 h-5" />
                  Browse Equipment
                </Link>
              </div>

              {/* Stats */}
              <div className="mt-12 grid grid-cols-3 gap-6">
                <div>
                  <div className="text-3xl font-extrabold text-green-700">500+</div>
                  <div className="text-sm text-neutral-500 mt-1">Equipment Listed</div>
                </div>
                <div>
                  <div className="text-3xl font-extrabold text-green-700">1,200+</div>
                  <div className="text-sm text-neutral-500 mt-1">Skilled Workers</div>
                </div>
                <div>
                  <div className="text-3xl font-extrabold text-green-700">300+</div>
                  <div className="text-sm text-neutral-500 mt-1">Transport Vehicles</div>
                </div>
              </div>
            </div>

            {/* Hero Image Card */}
            <div className="relative animate-fade-in">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.pexels.com/photos/2933243/pexels-photo-2933243.jpeg?auto=compress&cs=tinysrgb&w=1200"
                  alt="Indian farmer in field"
                  className="w-full h-[480px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-green-950/60 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-5 shadow-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
                        <Tractor className="w-6 h-6 text-green-700" />
                      </div>
                      <div>
                        <div className="font-bold text-neutral-900">Tractor Rental</div>
                        <div className="text-sm text-neutral-500">From ₹800/day near you</div>
                      </div>
                      <div className="ml-auto flex items-center gap-1 text-amber-500">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="text-sm font-semibold text-neutral-700">4.8</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating cards */}
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-lg p-4 hidden sm:block animate-fade-in">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                    <CloudSun className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-500">Weather Now</div>
                    <div className="font-bold text-neutral-900">28°C Sunny</div>
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-lg p-4 hidden sm:block animate-fade-in">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-700" />
                  </div>
                  <div>
                    <div className="text-xs text-neutral-500">Workers Available</div>
                    <div className="font-bold text-neutral-900">42 nearby</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-green-950">Everything You Need for Farming</h2>
            <p className="mt-4 text-lg text-neutral-500 max-w-2xl mx-auto">One platform for all your agricultural needs — from renting equipment to hiring skilled workers.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Tractor, title: "Equipment Rental", desc: "Rent tractors, harvesters, tillers, and more from owners near you.", link: "/equipment", color: "green" },
              { icon: Users, title: "Workforce Marketplace", desc: "Hire skilled farm workers by the day. Browse by skills and wages.", link: "/workers", color: "amber" },
              { icon: Truck, title: "Logistics & Transport", desc: "Book trucks and tractors for pickup, delivery, and transport.", link: "/transport", color: "blue" },
              { icon: CloudSun, title: "Weather Dashboard", desc: "Live temperature, rain forecast, humidity, and farming alerts.", link: "/weather", color: "green" },
              { icon: Sprout, title: "Crop Advisory", desc: "Get crop suggestions, fertilizer recommendations, and pest tips.", link: "/crop-advisory", color: "amber" },
              { icon: Share2, title: "Shared Booking", desc: "Split costs with nearby farmers through group bookings.", link: "/shared-booking", color: "blue" },
            ].map((service) => {
              const Icon = service.icon;
              const colors: Record<string, string> = {
                green: "bg-green-100 text-green-700 group-hover:bg-green-700 group-hover:text-white",
                amber: "bg-amber-100 text-amber-700 group-hover:bg-amber-600 group-hover:text-white",
                blue: "bg-blue-100 text-blue-700 group-hover:bg-blue-700 group-hover:text-white",
              };
              return (
                <Link key={service.title} to={service.link} className="card p-6 group hover:-translate-y-0.5 transition-all duration-200">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-5 transition-colors duration-200 ${colors[service.color]}`}>
                    <Icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900 mb-2">{service.title}</h3>
                  <p className="text-sm text-neutral-500 leading-relaxed">{service.desc}</p>
                  <div className="mt-4 flex items-center gap-1 text-sm font-semibold text-green-700 group-hover:gap-2 transition-all">
                    Learn More <ArrowRight className="w-4 h-4" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-green-950">How It Works</h2>
            <p className="mt-4 text-lg text-neutral-500">Get started in minutes — it's that simple.</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", icon: Search, title: "Search & Browse", desc: "Find equipment, workers, or transport near you with smart filters." },
              { step: "02", icon: Calendar, title: "Book & Schedule", desc: "Pick your dates, check availability, and book instantly." },
              { step: "03", icon: Wallet, title: "Pay Securely", desc: "Pay via UPI or card with Razorpay. Transparent pricing." },
              { step: "04", icon: Star, title: "Rate & Review", desc: "Share your experience and help the community grow." },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.step} className="relative">
                  <div className="text-5xl font-extrabold text-green-200 mb-3">{item.step}</div>
                  <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-green-700" />
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900 mb-2">{item.title}</h3>
                  <p className="text-sm text-neutral-500 leading-relaxed">{item.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Roles Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-green-950">Built for Everyone in Agriculture</h2>
            <p className="mt-4 text-lg text-neutral-500">Whether you farm, own equipment, work, or transport — there's a role for you.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Sprout, title: "Farmer", desc: "Rent equipment, hire workers, book transport, and get crop advice.", features: ["Browse & Book", "Weather Alerts", "Crop Advisory"] },
              { icon: Tractor, title: "Equipment Owner", desc: "List your machinery and earn income when you're not using it.", features: ["List Equipment", "Manage Bookings", "Track Earnings"] },
              { icon: Users, title: "Worker", desc: "Find farm jobs near you and build your reputation with ratings.", features: ["Job Marketplace", "Daily Wages", "Build Profile"] },
              { icon: Truck, title: "Transport Provider", desc: "Register your vehicle and accept delivery bookings.", features: ["Vehicle Listing", "Route History", "Accept Jobs"] },
            ].map((role) => {
              const Icon = role.icon;
              return (
                <div key={role.title} className="card p-6 hover:-translate-y-0.5 transition-all duration-200">
                  <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-green-700" />
                  </div>
                  <h3 className="text-lg font-bold text-neutral-900 mb-2">{role.title}</h3>
                  <p className="text-sm text-neutral-500 leading-relaxed mb-4">{role.desc}</p>
                  <ul className="space-y-2">
                    {role.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-neutral-700">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Trust/Features */}
      <section className="py-20 bg-green-950 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-extrabold mb-4">Why Farmers Trust Us</h2>
              <p className="text-green-100/80 text-lg leading-relaxed mb-8">
                We're building the infrastructure for modern Indian agriculture — transparent, community-driven, and built to save you money.
              </p>
              <div className="space-y-5">
                {[
                  { icon: Shield, title: "Verified Listings", desc: "Every equipment owner and worker is verified for your safety." },
                  { icon: Wallet, title: "Transparent Pricing", desc: "No hidden charges. See the full cost before you book." },
                  { icon: MapPin, title: "Location-Based", desc: "Find resources near you with smart location matching." },
                  { icon: Bell, title: "Real-Time Notifications", desc: "Get instant updates on bookings, payments, and deliveries." },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.title} className="flex gap-4">
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-green-800 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{item.title}</h3>
                        <p className="text-sm text-green-100/70 mt-0.5">{item.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1628026/pexels-photo-1628026.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Farm equipment in field"
                className="rounded-3xl shadow-2xl w-full h-[400px] object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-5 max-w-[240px]">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-amber-600" />
                  </div>
                  <div className="font-bold text-neutral-900">Save up to 60%</div>
                </div>
                <p className="text-sm text-neutral-500">On equipment costs through shared bookings and rentals.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-700 to-green-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">Ready to Get Started?</h2>
          <p className="text-green-100 text-lg mb-8 max-w-2xl mx-auto">
            Join thousands of farmers, equipment owners, and workers on Rento KrishiShare today.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link to={session ? "/dashboard" : "/register"} className="btn-amber text-base">
              Create Free Account
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link to="/support" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/20 transition-all duration-150">
              <LifeBuoy className="w-5 h-5" />
              Contact Support
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
