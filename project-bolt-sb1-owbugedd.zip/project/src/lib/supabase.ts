import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

export type UserRole = 'farmer' | 'equipment_owner' | 'worker' | 'transport_provider' | 'admin';

export interface Profile {
  id: string;
  full_name: string;
  phone: string | null;
  role: UserRole;
  location: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Equipment {
  id: string;
  owner_id: string;
  name: string;
  category: string;
  description: string | null;
  daily_rate: number;
  image_url: string | null;
  location: string | null;
  available: boolean;
  created_at: string;
  updated_at: string;
}

export interface Worker {
  id: string;
  user_id: string;
  skills: string;
  daily_wage: number;
  experience_years: number;
  location: string | null;
  available: boolean;
  created_at: string;
  updated_at: string;
}

export interface Transport {
  id: string;
  provider_id: string;
  vehicle_type: string;
  vehicle_number: string | null;
  capacity: string | null;
  driver_name: string | null;
  daily_rate: number;
  location: string | null;
  available: boolean;
  created_at: string;
  updated_at: string;
}

export interface Booking {
  id: string;
  booker_id: string;
  listing_type: 'equipment' | 'worker' | 'transport';
  listing_id: string;
  start_date: string;
  end_date: string;
  total_cost: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface Review {
  id: string;
  reviewer_id: string;
  listing_type: 'equipment' | 'worker' | 'transport';
  listing_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  description: string | null;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  priority: 'low' | 'medium' | 'high';
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'booking' | 'payment' | 'weather' | 'transport' | 'system' | 'review' | 'shared_booking';
  title: string;
  message: string;
  is_read: boolean;
  link: string | null;
  created_at: string;
}

export interface SharedBooking {
  id: string;
  creator_id: string;
  listing_type: 'equipment' | 'worker' | 'transport';
  listing_id: string;
  start_date: string;
  end_date: string;
  total_cost: number;
  per_person_cost: number;
  max_participants: number;
  current_participants: number;
  status: 'open' | 'full' | 'closed' | 'completed';
  location: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface SharedBookingParticipant {
  id: string;
  shared_booking_id: string;
  user_id: string;
  status: 'joined' | 'left';
  joined_at: string;
}

export interface TransportTracking {
  id: string;
  booking_id: string;
  transport_id: string;
  provider_id: string;
  status: 'pending' | 'picked_up' | 'in_transit' | 'delivered' | 'cancelled';
  current_location: string | null;
  latitude: number | null;
  longitude: number | null;
  estimated_arrival: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface AIRecommendation {
  id: string;
  user_id: string;
  type: 'equipment' | 'worker' | 'transport' | 'crop' | 'weather_alert';
  title: string;
  description: string;
  confidence_score: number;
  metadata: Record<string, any> | null;
  is_dismissed: boolean;
  created_at: string;
}

export interface Payment {
  id: string;
  user_id: string;
  booking_id: string | null;
  razorpay_order_id: string | null;
  razorpay_payment_id: string | null;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  listing_type: string | null;
  listing_name: string | null;
  payment_method: string | null;
  created_at: string;
  updated_at: string;
}
